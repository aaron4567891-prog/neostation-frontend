import 'dart:io';
import 'dart:convert';
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart'; // Required for rootBundle
import 'package:path/path.dart' as path; // Required for path operations
import 'package:sqlite3/sqlite3.dart' as sqlite; // sqlite3 usage
import '../../services/android_service.dart';

import '../../models/system_model.dart';
import '../../models/system_configuration.dart';
import '../../models/emulator_model.dart';
import '../../models/core_emulator_model.dart';
// import '../models/neo_sync_models.dart'; // Removido si no se usa directamente aquí
import '../../models/database_game_model.dart';
import '../../constants/system_folder_names.dart';
import '../../utils/cloud_path_builder.dart';
import '../../utils/semaphore.dart';
import 'sqlite_migrations.dart';
import '../../services/config_service.dart'; // Required for ConfigService usage
import '../../services/json_config_service.dart';
import '../../services/logger_service.dart';

/// Defines the behavior when a constraint violation occurs during a database operation.
enum ConflictAlgorithm { rollback, abort, fail, ignore, replace }

/// Interface that defines common database execution operations.
///
/// This adapter facilitates consistent interaction with the underlying SQLite database,
/// providing methods for raw SQL execution and high-level query builders.
abstract class DatabaseExecutorAdapter {
  /// Executes a raw SQL statement with optional [arguments].
  Future<void> execute(String sql, [List<Object?>? arguments]);

  /// Executes an INSERT statement and returns the ID of the last inserted row.
  Future<int> rawInsert(String sql, [List<Object?>? arguments]);

  /// Executes an UPDATE statement and returns the number of modified rows.
  Future<int> rawUpdate(String sql, [List<Object?>? arguments]);

  /// Executes a DELETE statement and returns the number of deleted rows.
  Future<int> rawDelete(String sql, [List<Object?>? arguments]);

  /// Executes a raw SQL query and returns a list of result maps.
  Future<List<Map<String, Object?>>> rawQuery(
    String sql, [
    List<Object?>? arguments,
  ]);

  /// Performs a high-level query on a specific [table].
  Future<List<Map<String, Object?>>> query(
    String table, {
    bool? distinct,
    List<String>? columns,
    String? where,
    List<Object?>? whereArgs,
    String? groupBy,
    String? having,
    String? orderBy,
    int? limit,
    int? offset,
  });

  /// Inserts a map of [values] into the specified [table].
  Future<int> insert(
    String table,
    Map<String, Object?> values, {
    String? nullColumnHack,
    ConflictAlgorithm? conflictAlgorithm,
  });

  /// Updates rows in [table] with new [values] matching the [where] clause.
  Future<int> update(
    String table,
    Map<String, Object?> values, {
    String? where,
    List<Object?>? whereArgs,
    ConflictAlgorithm? conflictAlgorithm,
  });

  /// Deletes rows from [table] matching the [where] clause.
  Future<int> delete(String table, {String? where, List<Object?>? whereArgs});

  /// Creates a new batch operation for atomic execution.
  BatchAdapter batch();
}

/// Concrete implementation of [DatabaseExecutorAdapter] using `package:sqlite3`.
class DatabaseAdapter implements DatabaseExecutorAdapter {
  final sqlite.Database _db;
  DatabaseAdapter(this._db);

  /// Provides access to the raw sqlite3 database instance.
  sqlite.Database get rawDb => _db;

  /// Closes the database connection.
  Future<void> close() async {
    _db.close();
  }

  @override
  Future<void> execute(String sql, [List<Object?>? arguments]) async {
    if (arguments != null && arguments.isNotEmpty) {
      _db.execute(sql, arguments);
    } else {
      _db.execute(sql);
    }
  }

  @override
  Future<int> rawInsert(String sql, [List<Object?>? arguments]) async {
    _db.execute(sql, arguments ?? []);
    return _db.lastInsertRowId;
  }

  @override
  Future<int> rawUpdate(String sql, [List<Object?>? arguments]) async {
    _db.execute(sql, arguments ?? []);
    return _db.updatedRows;
  }

  @override
  Future<int> rawDelete(String sql, [List<Object?>? arguments]) async {
    _db.execute(sql, arguments ?? []);
    return _db.updatedRows;
  }

  @override
  Future<List<Map<String, Object?>>> rawQuery(
    String sql, [
    List<Object?>? arguments,
  ]) async {
    final results = _db.select(sql, arguments ?? []);
    return _resultSetToMap(results);
  }

  /// Converts an [sqlite.ResultSet] into a standard Dart list of maps.
  List<Map<String, dynamic>> _resultSetToMap(sqlite.ResultSet results) {
    if (results.isEmpty) return [];

    final keys = results.columnNames;
    // Map each row (which is a generic list of values) to a Map using column names
    return results.map((row) {
      final map = <String, dynamic>{};
      for (int i = 0; i < keys.length; i++) {
        // ignore: collection_methods_unrelated_type
        map[keys[i]] = row[i];
      }
      return map;
    }).toList();
  }

  @override
  Future<List<Map<String, Object?>>> query(
    String table, {
    bool? distinct,
    List<String>? columns,
    String? where,
    List<Object?>? whereArgs,
    String? groupBy,
    String? having,
    String? orderBy,
    int? limit,
    int? offset,
  }) async {
    final buffer = StringBuffer('SELECT ');
    if (distinct == true) buffer.write('DISTINCT ');
    if (columns != null && columns.isNotEmpty) {
      buffer.write(columns.join(', '));
    } else {
      buffer.write('*');
    }
    buffer.write(' FROM $table');
    if (where != null) buffer.write(' WHERE $where');
    if (groupBy != null) buffer.write(' GROUP BY $groupBy');
    if (having != null) buffer.write(' HAVING $having');
    if (orderBy != null) buffer.write(' ORDER BY $orderBy');
    if (limit != null) buffer.write(' LIMIT $limit');
    if (offset != null) buffer.write(' OFFSET $offset');

    return rawQuery(buffer.toString(), whereArgs);
  }

  @override
  Future<int> insert(
    String table,
    Map<String, Object?> values, {
    String? nullColumnHack,
    ConflictAlgorithm? conflictAlgorithm,
  }) async {
    if (values.isEmpty) {
      final nullCol = nullColumnHack ?? 'NULL';
      return rawInsert('INSERT INTO $table ($nullCol) VALUES (NULL)');
    }

    final conflictClause = _getConflictClause(conflictAlgorithm);
    final cols = values.keys.join(', ');
    final placeholders = List.filled(values.length, '?').join(', ');

    final sql =
        'INSERT $conflictClause INTO $table ($cols) VALUES ($placeholders)';
    return rawInsert(sql, values.values.toList());
  }

  @override
  Future<int> update(
    String table,
    Map<String, Object?> values, {
    String? where,
    List<Object?>? whereArgs,
    ConflictAlgorithm? conflictAlgorithm,
  }) async {
    if (values.isEmpty) return 0;

    final conflictClause = _getConflictClause(conflictAlgorithm);
    final sets = values.keys.map((key) => '$key = ?').join(', ');
    final sql =
        'UPDATE $conflictClause $table SET $sets${where != null ? ' WHERE $where' : ''}';

    final args = [...values.values, ...(whereArgs ?? [])];
    return rawUpdate(sql, args);
  }

  @override
  Future<int> delete(
    String table, {
    String? where,
    List<Object?>? whereArgs,
  }) async {
    final sql = 'DELETE FROM $table${where != null ? ' WHERE $where' : ''}';
    return rawDelete(sql, whereArgs);
  }

  String _getConflictClause(ConflictAlgorithm? algo) {
    if (algo == null) return '';
    switch (algo) {
      case ConflictAlgorithm.rollback:
        return 'OR ROLLBACK';
      case ConflictAlgorithm.abort:
        return 'OR ABORT';
      case ConflictAlgorithm.fail:
        return 'OR FAIL';
      case ConflictAlgorithm.ignore:
        return 'OR IGNORE';
      case ConflictAlgorithm.replace:
        return 'OR REPLACE';
    }
  }

  @override
  BatchAdapter batch() => BatchAdapter(_db);

  /// Serializes transactions opened against this connection.
  ///
  /// Every caller shares one [sqlite.Database], and `package:sqlite3` is
  /// synchronous, so a statement executed while someone else holds `BEGIN`
  /// joins *their* transaction whether it meant to or not.
  static final Semaphore _transactionLock = Semaphore(1);

  /// Marks the async task that currently owns the open transaction.
  ///
  /// Zone values propagate into the continuations of the guarded action, so a
  /// nested [transaction] call from inside the body sees its own connection
  /// here while an unrelated task does not.
  static const Object _transactionOwnerKey = #sqliteTransactionOwner;

  /// Executes a series of database operations within an atomic transaction.
  ///
  /// Concurrent callers are serialized: a second task waits for the first to
  /// commit rather than writing into its transaction. Genuine nesting still
  /// runs inline on the outermost transaction — first-run setup does this three
  /// levels deep (`_onCreate` → `_insertInitialData` →
  /// `_executeSqlFileOptimized`) — which is why ownership is tracked per task
  /// instead of read back off the connection.
  ///
  /// Previously this branched on `_db.autocommit`, which answers "is a
  /// transaction open" rather than "is it mine". Two overlapping writers
  /// therefore shared one transaction: the second returned success to its
  /// caller with nothing committed, and the first's rollback discarded its work
  /// as well. Where both wrote the same UNIQUE column the collision surfaced as
  /// a constraint violation; everywhere else it was silent.
  Future<T> transaction<T>(
    Future<T> Function(TransactionAdapter) action,
  ) async {
    if (identical(Zone.current[_transactionOwnerKey], _db)) {
      return await action(TransactionAdapter(_db));
    }

    await _transactionLock.acquire();
    try {
      _db.execute('BEGIN');
      try {
        final result = await runZoned(
          () => action(TransactionAdapter(_db)),
          zoneValues: {_transactionOwnerKey: _db},
        );
        _db.execute('COMMIT');
        return result;
      } catch (e) {
        if (!_db.autocommit) {
          _db.execute('ROLLBACK');
        }
        rethrow;
      }
    } finally {
      _transactionLock.release();
    }
  }
}

class TransactionAdapter extends DatabaseAdapter {
  TransactionAdapter(super.db);
}

class BatchAdapter {
  final sqlite.Database _db;
  final List<Future<Object?> Function()> _actions = [];

  BatchAdapter(this._db);

  void rawInsert(String sql, [List<Object?>? arguments]) {
    _actions.add(() async {
      final adapter = DatabaseAdapter(_db);
      return await adapter.rawInsert(sql, arguments);
    });
  }

  void insert(
    String table,
    Map<String, Object?> values, {
    String? nullColumnHack,
    ConflictAlgorithm? conflictAlgorithm,
  }) {
    _actions.add(() async {
      final adapter = DatabaseAdapter(_db);
      return await adapter.insert(
        table,
        values,
        nullColumnHack: nullColumnHack,
        conflictAlgorithm: conflictAlgorithm,
      );
    });
  }

  void rawUpdate(String sql, [List<Object?>? arguments]) {
    _actions.add(() async {
      final adapter = DatabaseAdapter(_db);
      return await adapter.rawUpdate(sql, arguments);
    });
  }

  void update(
    String table,
    Map<String, Object?> values, {
    String? where,
    List<Object?>? whereArgs,
    ConflictAlgorithm? conflictAlgorithm,
  }) {
    _actions.add(() async {
      final adapter = DatabaseAdapter(_db);
      return await adapter.update(
        table,
        values,
        where: where,
        whereArgs: whereArgs,
        conflictAlgorithm: conflictAlgorithm,
      );
    });
  }

  void rawDelete(String sql, [List<Object?>? arguments]) {
    _actions.add(() async {
      final adapter = DatabaseAdapter(_db);
      return await adapter.rawDelete(sql, arguments);
    });
  }

  void delete(String table, {String? where, List<Object?>? whereArgs}) {
    _actions.add(() async {
      final adapter = DatabaseAdapter(_db);
      return await adapter.delete(table, where: where, whereArgs: whereArgs);
    });
  }

  void execute(String sql, [List<Object?>? arguments]) {
    _actions.add(() async {
      final adapter = DatabaseAdapter(_db);
      return await adapter.execute(sql, arguments);
    });
  }

  void query(
    String table, {
    bool? distinct,
    List<String>? columns,
    String? where,
    List<Object?>? whereArgs,
    String? groupBy,
    String? having,
    String? orderBy,
    int? limit,
    int? offset,
  }) {
    _actions.add(() async {
      final adapter = DatabaseAdapter(_db);
      return await adapter.query(
        table,
        distinct: distinct,
        columns: columns,
        where: where,
        whereArgs: whereArgs,
        groupBy: groupBy,
        having: having,
        orderBy: orderBy,
        limit: limit,
        offset: offset,
      );
    });
  }

  void rawQuery(String sql, [List<Object?>? arguments]) {
    _actions.add(() async {
      final adapter = DatabaseAdapter(_db);
      return await adapter.rawQuery(sql, arguments);
    });
  }

  BatchAdapter batch() {
    throw UnimplementedError('BatchAdapter cannot create nested batches.');
  }

  Future<List<Object?>> commit({bool? noResult}) async {
    final results = <Object?>[];
    final bool inTransaction = !_db.autocommit;

    if (!inTransaction) _db.execute('BEGIN');
    try {
      for (final action in _actions) {
        final result = await action();
        if (noResult != true) results.add(result);
      }
      if (!inTransaction) _db.execute('COMMIT');
    } catch (e) {
      if (!inTransaction && !_db.autocommit) {
        _db.execute('ROLLBACK');
      }
      rethrow;
    }
    return results;
  }
}

/// Core SQLite service responsible for database initialization, schema management,
/// and high-level data access for the entire application.
class SqliteService {
  // Singleton pattern
  static final SqliteService _instance = SqliteService._internal();
  static SqliteService get instance => _instance;
  SqliteService._internal();

  // Database configuration
  static const int _databaseVersion = 157;
  static const String _databaseName = 'data.sqlite';

  DatabaseAdapter? _database;
  bool _initialized = false;

  // Logging system
  static final _log = LoggerService.instance;

  // Cache for systems to avoid repeated DB/JSON reads using getSystemByFolderName
  static List<SystemModel>? _cachedSystems;

  /// Injects a [DatabaseAdapter] for unit testing purposes.
  ///
  /// This bypasses normal filesystem initialization and should only be called
  /// from test code.
  @visibleForTesting
  static void setTestingDatabase(DatabaseAdapter adapter) {
    instance._database = adapter;
    instance._initialized = true;
    instance._initCompleter = null;
    _cachedSystems = null;
  }

  /// Loads system definitions from JSON assets and synchronizes them with
  /// the database to maintain referential integrity.
  static Future<List<SystemModel>> loadAndSyncSystems() async {
    final configurations = await JsonConfigService.instance.loadSystems();
    final synced = await syncSystems(configurations);
    _cachedSystems = synced;
    return synced;
  }

  /// Loads all registered systems directly from the database, enriching them
  /// with metadata and game counts.
  static Future<List<SystemModel>> loadSystemsFromDb() async {
    final db = await instance.database;

    // Retrieve base systems with user settings and calculated ROM counts
    final systemsResults = await db.rawQuery('''
      SELECT s.*,
             (SELECT COUNT(*) FROM user_roms ur WHERE ur.app_system_id = s.id AND ur.is_hidden = 0) as rom_count,
             ss.recursive_scan,
             ss.custom_background_path,
             ss.custom_logo_path,
             ss.hide_logo,
             ss.hide_extension,
             ss.hide_parentheses,
             ss.hide_brackets,
             ss.subfolder_view
      FROM app_systems s
      LEFT JOIN user_system_settings ss ON s.id = ss.app_system_id
    ''');

    if (systemsResults.isEmpty) {
      // If the database is empty, force a synchronization from JSON resources.
      return await loadAndSyncSystems();
    }

    return await _enrichSystemsWithFoldersAndExtensions(db, systemsResults);
  }

  /// Synchronizes system configurations between JSON definitions and the local database.
  ///
  /// This process ensures that system IDs, metadata, and platform-specific assets
  /// are consistent, preserving user settings while updating core system data.
  static Future<List<SystemModel>> syncSystems(
    List<SystemConfiguration> configurations,
  ) async {
    final db = await instance.database;
    final syncedSystems = <SystemModel>[];
    final Set<String> syncedSystemIds = {};

    // The global "Show Subfolders" choice, so a system this sync adds for the
    // first time (a systems update shipping a new platform) starts out matching
    // the rest of the library instead of silently opting out of it.
    final userConfig = await getUserConfig();
    final subfolderViewAll =
        (int.tryParse(userConfig?['subfolder_view_all']?.toString() ?? '0') ??
            0) ==
        1;

    // Cache OS IDs
    final osMap = <String, int>{};
    final osResults = await db.query('app_os');
    for (final row in osResults) {
      osMap[row['name'].toString().toLowerCase()] =
          int.tryParse(row['id']?.toString() ?? '') ?? 0;
    }

    await db.transaction((txn) async {
      for (final config in configurations) {
        final jsonSystem = config.system;

        // Search by folder_name (the logical unique key)
        final existing = await txn.query(
          'app_systems',
          columns: ['id'],
          where: 'folder_name = ? COLLATE NOCASE',
          whereArgs: [jsonSystem.folderName],
          limit: 1,
        );

        String systemId;
        if (existing.isNotEmpty) {
          systemId = existing.first['id'].toString();
          await txn.update(
            'app_systems',
            {
              'real_name': jsonSystem.realName,
              'short_name': jsonSystem.shortName,
              'screenscraper_id': jsonSystem.screenscraperId,
              'ra_id': jsonSystem.raId,
              'ra_hash_algo': jsonSystem.raHashAlgo,
              'ra_hash_mode': jsonSystem.raHashMode,
              'description': jsonSystem.description,
              'launch_date': jsonSystem.launchDate,
              'manufacturer': jsonSystem.manufacturer,
              'type': jsonSystem.type,
              'color1': jsonSystem.color1,
              'color2': jsonSystem.color2,
              'multidisc': jsonSystem.multiDisc ? 1 : 0,
            },
            where: 'id = ?',
            whereArgs: [systemId],
          );
        } else {
          systemId = jsonSystem.folderName;
          await txn.insert('app_systems', {
            'id': systemId,
            'real_name': jsonSystem.realName,
            'short_name': jsonSystem.shortName,
            'folder_name': jsonSystem.folderName,
            'screenscraper_id': jsonSystem.screenscraperId,
            'ra_id': jsonSystem.raId,
            'ra_hash_algo': jsonSystem.raHashAlgo,
            'ra_hash_mode': jsonSystem.raHashMode,
            'description': jsonSystem.description,
            'launch_date': jsonSystem.launchDate,
            'manufacturer': jsonSystem.manufacturer,
            'type': jsonSystem.type,
            'color1': jsonSystem.color1,
            'color2': jsonSystem.color2,
            'multidisc': jsonSystem.multiDisc ? 1 : 0,
            'neosync_json': json.encode(jsonSystem.neosync.toJson()),
          });

          // Only for a brand-new system: an existing one keeps whatever the
          // user set on it, and a virtual system never reads the flag.
          if (subfolderViewAll &&
              !SystemFolderNames.subfolderViewExcluded.contains(
                jsonSystem.folderName,
              )) {
            await txn.insert('user_system_settings', {
              'app_system_id': systemId,
              'subfolder_view': 1,
              'updated_at': DateTime.now().toIso8601String(),
            }, conflictAlgorithm: ConflictAlgorithm.ignore);
          }
        }

        // SYNC FOLDERS: Source of Truth is JSON. Overwrite DB.
        // 1. Delete all existing folders for this system
        await txn.delete(
          'app_system_folders',
          where: 'system_id = ?',
          whereArgs: [systemId],
        );

        // 2. Insert all folders from JSON
        for (final folder in jsonSystem.folders) {
          if (folder.isNotEmpty) {
            await txn.insert('app_system_folders', {
              'system_id': systemId,
              'folder_name': folder,
            }, conflictAlgorithm: ConflictAlgorithm.ignore);
          }
        }

        // 3. Convert singular folder_name to an entry if missing (legacy support/consistency)
        if (jsonSystem.folderName.isNotEmpty &&
            !jsonSystem.folders.contains(jsonSystem.folderName)) {
          await txn.insert('app_system_folders', {
            'system_id': systemId,
            'folder_name': jsonSystem.folderName,
          }, conflictAlgorithm: ConflictAlgorithm.ignore);
        }

        syncedSystemIds.add(systemId);

        // Sync Extensions
        // First delete existing extensions to ensure full sync
        await txn.delete(
          'app_system_extensions',
          where: 'system_id = ?',
          whereArgs: [systemId],
        );

        // Insert new extensions
        for (final extension in jsonSystem.extensions) {
          await txn.insert('app_system_extensions', {
            'system_id': systemId,
            'extension': extension.toLowerCase().replaceAll('.', ''),
          });
        }

        // Sync Emulators for this system
        await _syncEmulators(
          txn,
          systemId,
          config.emulators, // Non-nullable in SystemConfiguration
          osMap,
          jsonSystem.folderName,
        );

        syncedSystems.add(jsonSystem.copyWith(id: systemId));
      }

      // PRUNING: Remove systems that are no longer present in the JSON source.
      if (syncedSystemIds.isNotEmpty) {
        final placeholders = List.filled(syncedSystemIds.length, '?').join(',');
        await txn.delete(
          'app_systems',
          where: 'id NOT IN ($placeholders)',
          whereArgs: syncedSystemIds.toList(),
        );
      }
    });

    return syncedSystems;
  }

  /// Runs one emulator sync pass against [txn] — the seed data applied to the
  /// database, including which row ends up carrying `is_default`.
  @visibleForTesting
  static Future<void> syncEmulatorsForTesting(
    TransactionAdapter txn,
    String systemId,
    List<EmulatorDefinition> emulators,
    Map<String, int> osMap,
  ) => _syncEmulators(txn, systemId, emulators, osMap, systemId);

  static Future<void> _syncEmulators(
    TransactionAdapter txn,
    String systemId,
    List<EmulatorDefinition> emulators,
    Map<String, int> osMap,
    String systemFolderName,
  ) async {
    // The invariant is "at most one default per (system_id, os_id)", so every
    // default bookkeeping below is scoped per OS. Scoping it per system would
    // both starve secondary platforms of a default (the first OS in the JSON
    // wins and every other OS silently gets none) and let a stale default on
    // one OS suppress the JSON default on another.

    // Existing user-chosen defaults for this system, per OS. A user choice
    // outranks the seed data, so these operating systems are left entirely
    // alone below — [_fixEmulatorDefaults] already keeps `is_default` from
    // contradicting them.
    final userDefaultRows = await txn.rawQuery(
      '''
      SELECT e.os_id as os_id, COUNT(*) as count
      FROM user_emulator_config uc
      JOIN app_emulators e ON uc.emulator_unique_id = e.unique_identifier
      WHERE e.system_id = ? AND uc.is_user_default = 1
      GROUP BY e.os_id
      ''',
      [systemId],
    );

    final Set<int> osWithUserDefault = {};
    for (final row in userDefaultRows) {
      final rowOsId = int.tryParse(row['os_id']?.toString() ?? '');
      final rowCount = int.tryParse(row['count']?.toString() ?? '') ?? 0;
      if (rowOsId != null && rowCount > 0) {
        osWithUserDefault.add(rowOsId);
      }
    }

    // The emulator the systems JSON designates for each OS — the first flagged
    // entry that is actually applicable there. Recorded during the row loop and
    // enforced once afterwards, because the flag is only meaningful relative to
    // the other rows of the same (system_id, os_id).
    final Map<int, String> osJsonPick = {};

    final Set<String> processedUniqueIds = {};

    for (final emuDef in emulators) {
      for (final platformEntry in emuDef.platforms.entries) {
        final osName = platformEntry.key.toLowerCase();

        // Case-insensitive lookup for OS ID
        int? osId = osMap[osName];
        if (osId == null) {
          // Try finding key case-insensitively
          for (final key in osMap.keys) {
            if (key.toLowerCase() == osName) {
              osId = osMap[key];
              break;
            }
          }
        }

        if (osId == null) continue;

        // --- FILTER: Android-specific emulators on Desktop ---
        // Prevents "RetroArch32" or "RetroArch64" from appearing on Linux/Windows/Mac
        // if they are just duplicates of the main RetroArch core with invalid configs.
        // We only allow these if the CURRENT platform key in JSON is strictly 'android'.
        // But the loop iterates all keys.
        // We need to check if we are inserting a Desktop OS entry for a "ra32/ra64" emulator.

        final isDesktopTarget = ['linux', 'windows', 'macos'].contains(osName);
        if (isDesktopTarget) {
          final lowerName = emuDef.name.toLowerCase();
          final isAndroidVariant =
              lowerName.contains('ra32') ||
              lowerName.contains('ra64') ||
              lowerName.contains('retroarch32') ||
              lowerName.contains('retroarch64');

          if (isAndroidVariant) {
            continue;
          }
        }
        // -----------------------------------------------------

        final platformData = platformEntry.value as Map<String, dynamic>;

        // Determine if core or standalone
        bool isStandalone = true;
        String? coreFilename;
        String? packageName;
        String? executable;

        if (osName == 'android') {
          packageName = platformData['package'];
          String? activityName = platformData['activity'];

          // Parse launch_arguments if package/activity are missing (new format)
          if ((packageName == null || activityName == null) &&
              platformData.containsKey('launch_arguments')) {
            final args = platformData['launch_arguments'].toString();

            // Extract package and activity from "-n package/activity"
            final componentMatch = RegExp(
              r'-n\s+([^\s/]+)/([^\s]+)',
            ).firstMatch(args);
            if (componentMatch != null) {
              packageName ??= componentMatch.group(1);
              var activity = componentMatch.group(2)!;
              if (activity.startsWith('.') && packageName != null) {
                activity = '$packageName$activity';
              }
              activityName ??= activity;
            }

            // Check if RetroArch
            if (packageName != null && packageName.contains('retroarch')) {
              isStandalone = false;
              // Extract core from '--es LIBRETRO "corename"' or similar
              // Case insensitive check for LIBRETRO
              final coreMatch = RegExp(
                r'--es\s+LIBRETRO\s+"?([^"\s]+)"?',
                caseSensitive: false,
              ).firstMatch(args);
              if (coreMatch != null) {
                coreFilename = coreMatch.group(1);
              }
            }
          } else {
            // Legacy format check
            if (packageName != null && packageName.contains('retroarch')) {
              isStandalone = false;
              // Get core from extras
              final extras = platformData['extras'];
              if (extras != null && extras is List) {
                for (final extra in extras) {
                  if (extra['key'] == 'LIBRETRO') {
                    coreFilename = extra['value'];
                  }
                }
              }
            }
          }

          // Persist the resolved activity alongside the package so standalone
          // fallback launches have a complete component name.
          platformData['_resolved_activity_name'] = activityName;
        } else if (osName == 'windows') {
          executable = platformData['executable'];
          if (executable != null &&
              executable.toLowerCase().contains('retroarch')) {
            isStandalone = false;
          }
          final args = platformData['args'];
          if (args != null) {
            final match = RegExp(
              r'-L\s+(?:cores\\|cores/)?([\w_\-\.]+)',
            ).firstMatch(args);
            if (match != null) {
              coreFilename = match.group(1);
            }
          }
        } else if (osName == 'linux' || osName == 'macos') {
          executable = platformData['executable'];
          if (executable != null &&
              executable.toLowerCase().contains('retroarch')) {
            isStandalone = false;
          }
          final args = platformData['args'];
          if (args != null) {
            final match = RegExp(
              r'-L\s+(?:cores\\|cores/)?([\w_\-\.]+)',
            ).firstMatch(args);
            if (match != null) {
              coreFilename = match.group(1);
            }
          }
        }

        // Determine DB name (Unique per System+OS)
        String dbName = emuDef.name;
        if (osName == 'android' && packageName != null) {
          if (packageName == 'com.retroarch.aarch64') {
            dbName = '${emuDef.name} (64-bit)';
          } else if (packageName == 'com.retroarch.ra32') {
            dbName = '${emuDef.name} (32-bit)';
          }
        }

        // Record which emulator the JSON designates for this OS. Nothing writes
        // `is_default` inside this loop: the flag only means anything relative
        // to the rest of the (system_id, os_id) group, so one statement after
        // the loop owns it — see the enforcement pass below.
        final bool isDefaultCore = emuDef.isDefaultCore;
        final bool isDefaultStandalone = emuDef.isDefaultStandalone;
        // On Android, skip setting is_default for RetroArch cores here;
        // RA detection (_fixRetroarchAndroidDefault) handles that separately.
        final bool isAndroidTarget = osName == 'android';
        final bool isRetroArchCore = isDefaultCore && !isStandalone;
        final bool skipCoreDefault = isAndroidTarget && isRetroArchCore;

        // First flagged entry wins the OS. Systems that flag several (the
        // ra/ra32/ra64 core trio, on desktop where none of them is skipped)
        // resolve by JSON array order, which is at least reproducible.
        if (!skipCoreDefault && (isDefaultCore || isDefaultStandalone)) {
          osJsonPick.putIfAbsent(osId, () => emuDef.uniqueId);
        }

        // Determine RetroAchievements compatibility
        final bool retroAchievementsCompatible =
            emuDef.isretroAchievementsCompatible ?? (!isStandalone);

        // Determine the NeoSync v2 cloud slug. RetroArch cores collapse all
        // variants (RA/RA64/RA32) into one `retroarch.<core>` slug so saves are
        // portable between them; standalone emulators use the declared slug or
        // a derivation from their unique id.
        String? neosyncSlug;
        if (!isStandalone) {
          neosyncSlug = CloudPathBuilder.retroArchCoreSlug(
            coreFilename ?? emuDef.uniqueId,
          );
        } else {
          neosyncSlug = emuDef.effectiveNeoSyncSlug;
        }

        // Insert/Update
        final existing = await txn.query(
          'app_emulators',
          columns: ['unique_identifier'],
          where: 'unique_identifier = ? AND os_id = ?',
          whereArgs: [emuDef.uniqueId, osId],
        );

        if (existing.isNotEmpty) {
          processedUniqueIds.add(emuDef.uniqueId);

          final Map<String, Object?> updateData = {
            'name': dbName,
            'is_standalone': isStandalone ? 1 : 0,
            'core_filename': coreFilename,
            'android_package_name': packageName,
            'android_activity_name': platformData['_resolved_activity_name'],
            'is_ra_compatible': retroAchievementsCompatible ? 1 : 0,
            'neosync_slug': neosyncSlug,
          };

          if (isDefaultCore) {
            updateData['is_default_core'] = 1;
          }
          // Written on every pass, unlike is_default_core: it is what tells the
          // RetroArch fallback which standalone the seed designates, so a JSON
          // that moves the flag has to be able to move it back off a row.
          updateData['is_default_standalone'] = isDefaultStandalone ? 1 : 0;

          await txn.update(
            'app_emulators',
            updateData,
            where: 'unique_identifier = ? AND os_id = ?',
            whereArgs: [emuDef.uniqueId, osId],
          );
        } else {
          // Fallback: check by name for transition (old records without unique_identifier)
          final existingByName = await txn.query(
            'app_emulators',
            columns: ['unique_identifier'],
            where:
                'system_id = ? AND os_id = ? AND name = ? AND unique_identifier IS NULL',
            whereArgs: [systemId, osId, dbName],
          );

          if (existingByName.isNotEmpty) {
            // Prepare update map
            final Map<String, Object?> updateData = {
              'unique_identifier': emuDef.uniqueId,
              'is_standalone': isStandalone ? 1 : 0,
              'core_filename': coreFilename,
              'android_package_name': packageName,
              'android_activity_name': platformData['_resolved_activity_name'],
              'is_ra_compatible': retroAchievementsCompatible ? 1 : 0,
              'neosync_slug': neosyncSlug,
            };
            if (isDefaultCore) {
              updateData['is_default_core'] = 1;
            }
            updateData['is_default_standalone'] = isDefaultStandalone ? 1 : 0;

            await txn.update(
              'app_emulators',
              updateData,
              where:
                  'system_id = ? AND os_id = ? AND name = ? AND unique_identifier IS NULL',
              whereArgs: [systemId, osId, dbName],
            );
            processedUniqueIds.add(emuDef.uniqueId);
          } else {
            // New emulator
            final Map<String, Object?> insertData = {
              'system_id': systemId,
              'os_id': osId,
              'name': dbName,
              'unique_identifier': emuDef.uniqueId,
              'is_standalone': isStandalone ? 1 : 0,
              'core_filename': coreFilename,
              'android_package_name': packageName,
              'android_activity_name': platformData['_resolved_activity_name'],
              // Assigned by the enforcement pass after the loop, which is the
              // only thing that can see the whole (system_id, os_id) group.
              'is_default': 0,
              'is_ra_compatible': retroAchievementsCompatible ? 1 : 0,
              'neosync_slug': neosyncSlug,
            };
            if (isDefaultCore) {
              insertData['is_default_core'] = 1;
            }
            insertData['is_default_standalone'] = isDefaultStandalone ? 1 : 0;

            await txn.insert('app_emulators', insertData);
            processedUniqueIds.add(emuDef.uniqueId);
          }
        }
      }
    }

    // Enforce the seed's pick for every OS the JSON designates one for.
    //
    // Setting `is_default` on the flagged row is not enough on its own: nothing
    // else in the sync path ever *clears* the flag, so a row that acquired it
    // under an older systems JSON (or from a repair pass that guessed) kept it
    // forever, and the seed's real choice could never take effect. Shipping a
    // changed default therefore never reached an install that already had one.
    // Writing the whole group in one statement makes the JSON authoritative and
    // collapses any duplicates in the same pass.
    //
    // Two owners are deliberately not overruled:
    //   * an OS where the user picked an emulator — their choice outranks the
    //     seed, and re-asserting `is_default` here would recreate exactly the
    //     app-default-contradicts-user-choice anomaly v105 exists to clear;
    //   * RetroArch on Android, where [fixRetroArchDefaultForAndroid] owns the
    //     flag because only it knows which variant is installed. Its cores are
    //     already excluded by `skipCoreDefault`; this also declines to demote a
    //     core it has designated in favour of the JSON's standalone.
    if (osJsonPick.isNotEmpty) {
      int? androidOsId;
      for (final entry in osMap.entries) {
        if (entry.key.toLowerCase() == 'android') {
          androidOsId = entry.value;
          break;
        }
      }

      final coreDefaultRows = await txn.rawQuery(
        'SELECT DISTINCT os_id FROM app_emulators '
        'WHERE system_id = ? AND is_default = 1 AND is_standalone = 0',
        [systemId],
      );
      final Set<int> osWithCoreDefault = {};
      for (final row in coreDefaultRows) {
        final rowOsId = int.tryParse(row['os_id']?.toString() ?? '');
        if (rowOsId != null) osWithCoreDefault.add(rowOsId);
      }

      for (final pick in osJsonPick.entries) {
        final pickOsId = pick.key;
        if (osWithUserDefault.contains(pickOsId)) continue;
        if (pickOsId == androidOsId && osWithCoreDefault.contains(pickOsId)) {
          continue;
        }

        await txn.rawUpdate(
          'UPDATE app_emulators '
          'SET is_default = CASE WHEN unique_identifier = ? THEN 1 ELSE 0 END '
          'WHERE system_id = ? AND os_id = ?',
          [pick.value, systemId, pickOsId],
        );
      }
    }

    // Prune logic: Delete emulators not in the processed list
    if (processedUniqueIds.isNotEmpty) {
      final placeholders = List.filled(
        processedUniqueIds.length,
        '?',
      ).join(',');

      // 1. Sever foreign key references in user_roms before deleting from app_emulators
      await txn.update(
        'user_roms',
        {'app_emulator_unique_id': null, 'app_emulator_os_id': null},
        where:
            'app_system_id = ? AND app_emulator_unique_id NOT IN ($placeholders)',
        whereArgs: [systemId, ...processedUniqueIds],
      );

      // 2. Clean up user_emulator_config
      final obsoleteEmulators = await txn.query(
        'app_emulators',
        columns: ['unique_identifier'],
        where: 'system_id = ? AND unique_identifier NOT IN ($placeholders)',
        whereArgs: [systemId, ...processedUniqueIds],
      );
      if (obsoleteEmulators.isNotEmpty) {
        final obsoleteIds = obsoleteEmulators
            .map((r) => r['unique_identifier'])
            .toList();
        final obsPlaceholders = List.filled(obsoleteIds.length, '?').join(',');
        await txn.delete(
          'user_emulator_config',
          where: 'emulator_unique_id IN ($obsPlaceholders)',
          whereArgs: obsoleteIds,
        );
      }

      // 3. Delete from app_emulators
      await txn.delete(
        'app_emulators',
        where: 'system_id = ? AND unique_identifier NOT IN ($placeholders)',
        whereArgs: [systemId, ...processedUniqueIds],
      );
    } else {
      // If no emulators were processed, delete all for this system
      // This handles the case where a system has no emulators defined in JSON
      if (emulators.isEmpty) {
        // 1. Sever foreign key references in user_roms
        await txn.update(
          'user_roms',
          {'app_emulator_unique_id': null, 'app_emulator_os_id': null},
          where: 'app_system_id = ?',
          whereArgs: [systemId],
        );

        // 2. Clean up user_emulator_config
        final obsoleteEmulators = await txn.query(
          'app_emulators',
          columns: ['unique_identifier'],
          where: 'system_id = ?',
          whereArgs: [systemId],
        );
        if (obsoleteEmulators.isNotEmpty) {
          final obsoleteIds = obsoleteEmulators
              .map((r) => r['unique_identifier'])
              .toList();
          final obsPlaceholders = List.filled(
            obsoleteIds.length,
            '?',
          ).join(',');
          await txn.delete(
            'user_emulator_config',
            where: 'emulator_unique_id IN ($obsPlaceholders)',
            whereArgs: obsoleteIds,
          );
        }

        // 3. Delete from app_emulators
        await txn.delete(
          'app_emulators',
          where: 'system_id = ?',
          whereArgs: [systemId],
        );
      }
    }
  }

  // Lock logging initialization to avoid recursion
  Completer<DatabaseAdapter>? _initCompleter;

  /// Provides the database instance (lazy initialization).
  Future<DatabaseAdapter> get database async {
    if (_database != null && _initialized) {
      return _database!;
    }

    // If an initialization is already in progress, wait for its completion.
    if (_initCompleter != null) {
      return _initCompleter!.future;
    }

    _initCompleter = Completer<DatabaseAdapter>();

    try {
      _database = await _initDatabase();
      _initCompleter!.complete(_database);
    } catch (e) {
      _initCompleter!.completeError(e);
      _initCompleter = null; // Allow retry on failure
      rethrow;
    }

    return _database!;
  }

  /// Initializes the database with versioning and migration support.
  Future<DatabaseAdapter> _initDatabase() async {
    String? dbPath;
    try {
      dbPath = await _getDatabasePath();
    } catch (e) {
      // On Android, this might fail if permissions haven't been granted yet.
      if (Platform.isAndroid && e.toString().contains('Permission denied')) {
        _log.w('Permission denied accessing DB. Waiting for SetupWizard...');
        throw Exception('StoragePermissionMissing');
      }
      rethrow;
    }

    _log.i('SQlite database init v$_databaseVersion');
    _log.i('Database path: $dbPath');

    // Ensure the directory exists.
    final dbDir = Directory(path.dirname(dbPath));
    if (!await dbDir.exists()) {
      await dbDir.create(recursive: true);
    }

    // Migration for Desktop platforms (Windows, Linux, MacOS)
    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      final userDataPath = await ConfigService.getUserDataPath();
      final appRoot = Directory(userDataPath).parent;

      final oldPathRoot = path.join(appRoot.path, _databaseName);
      final oldPathDbDir = path.join(appRoot.path, 'databases', _databaseName);

      if (await File(oldPathRoot).exists()) {
        await _attemptMigration(dbPath, File(oldPathRoot));
      } else if (await File(oldPathDbDir).exists()) {
        await _attemptMigration(dbPath, File(oldPathDbDir));
      }
    }

    try {
      return await _initDatabaseCore(dbPath);
    } on sqlite.SqliteException catch (e) {
      // If the error is I/O-related the WAL/SHM files are likely corrupted
      // from a previous crash (common on SD cards/exFAT). Clean them up and
      // retry once before giving up.
      if (_isDiskError(e)) {
        _log.w(
          'Disk I/O error opening database, cleaning WAL/SHM and retrying: $e',
        );
        await _cleanupWalFiles(dbPath);
        try {
          return await _initDatabaseCore(dbPath);
        } catch (retryError, stackTrace) {
          _log.e(
            'Error initializing database after WAL cleanup',
            error: retryError,
            stackTrace: stackTrace,
          );
          rethrow;
        }
      }
      rethrow;
    } catch (e, stackTrace) {
      _log.e('Error initializing database', error: e, stackTrace: stackTrace);
      rethrow;
    }
  }

  /// Core database initialization: open, configure, version check, migrate.
  Future<DatabaseAdapter> _initDatabaseCore(String dbPath) async {
    final db = sqlite.sqlite3.open(dbPath);
    final adapter = DatabaseAdapter(db);

    await _onConfigure(adapter);

    final versionResult = await adapter.rawQuery('PRAGMA user_version;');
    final currentVersion =
        int.tryParse(versionResult.first.values.first?.toString() ?? '') ?? 0;

    _log.i('Database version: $currentVersion');

    if (currentVersion == 0) {
      final existingTables = await adapter.rawQuery(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='user_config';",
      );
      if (existingTables.isNotEmpty) {
        _log.i(
          'Legacy install detected (version=0 but tables exist). Running migrations.',
        );
        await _onUpgrade(adapter, 0, _databaseVersion);
      } else {
        await _onCreate(adapter, _databaseVersion);
      }
    } else if (currentVersion < _databaseVersion) {
      await _onUpgrade(adapter, currentVersion, _databaseVersion);
    } else if (currentVersion > _databaseVersion) {
      await _onDowngrade(adapter, currentVersion, _databaseVersion);
    }

    await adapter.execute('PRAGMA user_version = $_databaseVersion;');

    _initialized = true;
    _log.i('Database initialized');

    return adapter;
  }

  /// Returns true when [error] is a [sqlite.SqliteException] caused by a disk
  /// I/O failure (e.g. code 4618 SQLITE_IOERR_SHORT_READ).
  bool _isDiskError(Object error) {
    if (error is sqlite.SqliteException) {
      final msg = error.toString().toLowerCase();
      return msg.contains('disk i/o error') || msg.contains('ioerr');
    }
    return false;
  }

  /// Deletes WAL and SHM journal files associated with the database at
  /// [dbPath]. These files can become corrupted after an improper shutdown,
  /// especially on SD cards / exFAT, and prevent the database from opening.
  Future<void> _cleanupWalFiles(String dbPath) async {
    for (final suffix in ['-wal', '-shm']) {
      try {
        final file = File('$dbPath$suffix');
        if (await file.exists()) {
          await file.delete();
          _log.i('Deleted stale journal file: ${file.path}');
        }
      } catch (e) {
        _log.w('Could not delete $suffix file: $e');
      }
    }
  }

  /// Configures the database session (runs before schema creation/upgrades).
  ///
  /// Pragma statements are wrapped individually so a filesystem error on one
  /// (e.g. an SD card that doesn't support WAL) doesn't block the entire DB.
  Future<void> _onConfigure(DatabaseAdapter db) async {
    // Set before anything else: the pragmas below and first-run creation all
    // write, and on dual-display devices a second Flutter engine writes to this
    // same file concurrently. Without a busy timeout the loser of a race fails
    // instantly with SQLITE_BUSY ("database is locked") instead of waiting for
    // the other connection to commit.
    //
    // 15s rather than a token value because [_onCreate] holds the write lock
    // for the whole of first-run seeding (122 systems, 2422 emulators). The
    // worst case is the first cold boot after an install, where ART is still
    // warming up: 5s was observed to expire there, and the timeout only ever
    // caps how long a blocked writer waits, so a generous bound costs nothing
    // on the uncontended path.
    try {
      await db.execute('PRAGMA busy_timeout = 15000;');
    } catch (e) {
      _log.w('Could not set PRAGMA busy_timeout = 15000: $e');
    }

    try {
      await db.execute('PRAGMA foreign_keys = ON;');
    } catch (e) {
      _log.w('Could not set PRAGMA foreign_keys = ON: $e');
    }

    try {
      await db.execute('PRAGMA synchronous = NORMAL;');
    } catch (e) {
      _log.w('Could not set PRAGMA synchronous = NORMAL: $e');
    }

    try {
      await db.execute('PRAGMA cache_size = 1000;');
    } catch (e) {
      _log.w('Could not set PRAGMA cache_size = 1000: $e');
    }

    try {
      await db.execute('PRAGMA temp_store = memory;');
    } catch (e) {
      _log.w('Could not set PRAGMA temp_store = memory: $e');
    }

    try {
      await db.execute('PRAGMA journal_mode = WAL;');
    } catch (e) {
      _log.w('Could not set PRAGMA journal_mode = WAL: $e');
    }

    // Verify critical tables exist before attempting hotfixes.
    // This prevents "no such table" errors during fresh initializations.
    final tables = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'",
    );
    final tableNames = tables.map((r) => r['name'].toString()).toSet();

    // Recovery guard: if the database already has tables but app_os is missing
    // (e.g. after a failed downgrade/recreate cycle), recreate it immediately so
    // downstream hotfixes and queries do not crash.
    if (tableNames.isNotEmpty && !tableNames.contains('app_os')) {
      _log.w(
        'app_os table is missing on an existing database; recreating it defensively.',
      );
      await _ensureAppOsTable(db);
      tableNames.add('app_os');
    }

    // Only run hotfixes if the target tables exist.

    // FIX: Ensure user_rom_folders exists even if migrations were skipped.
    // This is safe as it uses IF NOT EXISTS.
    await db.execute('''
      CREATE TABLE IF NOT EXISTS user_rom_folders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        path TEXT NOT NULL UNIQUE
      );
    ''');

    // Add newly created table to known set.
    if (!tableNames.contains('user_rom_folders')) {
      tableNames.add('user_rom_folders');
    }

    // FIX: Ensure user_custom_save_folders exists even if migrations were
    // skipped. NeoSync stores user-selected save folders per system + emulator.
    await db.execute('''
      CREATE TABLE IF NOT EXISTS user_custom_save_folders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        system_folder_name TEXT NOT NULL COLLATE NOCASE,
        emulator_slug TEXT NOT NULL,
        folder_path TEXT NOT NULL,
        UNIQUE(system_folder_name, emulator_slug)
      );
    ''');
    // A table created by an earlier feature branch may lack emulator_slug;
    // CREATE TABLE IF NOT EXISTS won't alter it, so add the column manually.
    try {
      final csfInfo = await db.rawQuery(
        'PRAGMA table_info(user_custom_save_folders)',
      );
      final hasEmulatorSlug = csfInfo.any(
        (c) => c['name'].toString() == 'emulator_slug',
      );
      if (!hasEmulatorSlug) {
        await db.execute(
          'ALTER TABLE user_custom_save_folders ADD COLUMN emulator_slug TEXT NOT NULL DEFAULT \'unknown\'',
        );
      }
    } catch (e) {
      _log.w('Could not ensure emulator_slug on user_custom_save_folders: $e');
    }
    if (!tableNames.contains('user_custom_save_folders')) {
      tableNames.add('user_custom_save_folders');
    }

    // FIX: Ensure user_screenscraper_config columns are up to date (v29).
    await _ensureScreenScraperConfigColumns(db);

    // FIX: Resolve inconsistencies in default emulator assignments.
    if (tableNames.contains('app_systems') &&
        tableNames.contains('app_emulators')) {
      try {
        await _fixEmulatorDefaults(db);
        await logEmulatorDefaultAnomalies(db);
      } catch (e) {
        _log.e('Minor fix for defaults failed (expected in first run): $e');
      }
    }

    // FIX: Mark standalone emulators as achievement compatible.
    if (tableNames.contains('app_emulators')) {
      try {
        await _fixAchievementCompatibility(db);
      } catch (e) {
        _log.e('Minor fix for achievements failed (expected in first run): $e');
      }
    }

    // FIX: Ensure user_system_settings includes v41 columns.
    if (tableNames.contains('user_system_settings')) {
      try {
        await _ensureSystemSettingsColumns(db);
      } catch (e) {
        _log.e('Minor fix for system settings failed: $e');
      }
    }

    // FIX: Ensure unique_identifier column in app_emulators.
    if (tableNames.contains('app_emulators')) {
      try {
        await _ensureEmulatorUniqueIdentifierColumn(db);
      } catch (e) {
        _log.e('Minor fix for emulator identifiers failed: $e');
      }
    }

    // FIX: Ensure is_default_core column in app_emulators.
    if (tableNames.contains('app_emulators')) {
      try {
        await _ensureEmulatorDefaultCoreColumn(db);
      } catch (e) {
        _log.e('Minor fix for emulator default core column failed: $e');
      }
    }

    // FIX: Ensure app_neo_sync_state exists (legacy support for v58). New
    // installs get the provider-scoped schema (v111); pre-existing tables are
    // upgraded by migration v111, so IF NOT EXISTS here never masks that.
    await db.execute(SqliteMigrations.createAppNeoSyncStateTableSql);
    // The index spans `provider`, which migration v111 adds — and this runs
    // *before* migrations. On a database still at the pre-v111 schema the
    // CREATE INDEX raises "no such column: provider" and aborts init before
    // v111 can ever run, leaving every launch to fail the same way. Create it
    // only once the column is there; v111 creates it as part of the upgrade.
    final neoSyncColumns = await db.rawQuery(
      'PRAGMA table_info(app_neo_sync_state);',
    );
    final hasProviderColumn = neoSyncColumns.any(
      (c) => c['name']?.toString() == 'provider',
    );
    if (hasProviderColumn) {
      await db.execute(SqliteMigrations.createAppNeoSyncStateIndexSql);
    }

    // The RomM tables are created by migration v111 and by the fresh-install
    // table list — the only two sources, per the maintainer's
    // versioned-migrations-only policy. No on-launch CREATE safety net here:
    // it would only mask a failed migration as a later runtime "no such table"
    // error instead of surfacing it.
  }

  /// Ensures the unique_identifier column exists in app_emulators.
  Future<void> _ensureEmulatorUniqueIdentifierColumn(DatabaseAdapter db) async {
    try {
      final tableInfo = await db.rawQuery('PRAGMA table_info(app_emulators)');
      final columns = tableInfo.map((c) => c['name'].toString()).toList();
      if (!columns.contains('unique_identifier')) {
        await db.execute(
          'ALTER TABLE app_emulators ADD COLUMN unique_identifier TEXT',
        );
      }
    } catch (e) {
      _log.e('Minor fix ensuring emulator unique identifier failed: $e');
      rethrow;
    }
  }

  /// Ensures the is_default_core column exists in app_emulators.
  Future<void> _ensureEmulatorDefaultCoreColumn(DatabaseAdapter db) async {
    try {
      final tableInfo = await db.rawQuery('PRAGMA table_info(app_emulators)');
      final columns = tableInfo.map((c) => c['name'].toString()).toList();
      if (!columns.contains('is_default_core')) {
        await db.execute(
          'ALTER TABLE app_emulators ADD COLUMN is_default_core INTEGER NOT NULL DEFAULT 0',
        );
      }
    } catch (e) {
      _log.e('Minor fix ensuring emulator default core column failed: $e');
      rethrow;
    }
  }

  /// Ensures the [app_os] lookup table exists and contains the base OS rows.
  ///
  /// This is a defensive guard used both during first install and as a recovery
  /// mechanism if the table was lost during a failed downgrade/recreate cycle.
  Future<void> _ensureAppOsTable(DatabaseAdapter db) async {
    try {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS app_os (
          id INTEGER PRIMARY KEY,
          name TEXT NOT NULL UNIQUE
        );
      ''');

      await db.execute('''
        INSERT OR IGNORE INTO app_os (id, name) VALUES
        (1, 'windows'),
        (2, 'android'),
        (3, 'linux'),
        (4, 'macos'),
        (5, 'ios')
      ''');
    } catch (e) {
      _log.e('Failed to ensure app_os table: $e');
      rethrow;
    }
  }

  /// Ensures core system columns exist in app_systems.
  Future<void> _ensureAppSystemsColumns(DatabaseAdapter db) async {
    try {
      final tableInfo = await db.rawQuery('PRAGMA table_info(app_systems)');
      final columns = tableInfo.map((c) => c['name'].toString()).toList();

      if (!columns.contains('manufacturer')) {
        await db.execute(
          'ALTER TABLE app_systems ADD COLUMN manufacturer TEXT',
        );
      }
      if (!columns.contains('type')) {
        await db.execute('ALTER TABLE app_systems ADD COLUMN type TEXT');
      }
    } catch (e) {
      _log.e('Minor fix ensuring app_systems columns failed: $e');
      rethrow;
    }
  }

  /// Ensures required columns exist in user_system_settings.
  Future<void> _ensureSystemSettingsColumns(DatabaseAdapter db) async {
    try {
      final tableInfo = await db.rawQuery(
        'PRAGMA table_info(user_system_settings)',
      );
      final columns = tableInfo.map((c) => c['name'].toString()).toList();

      if (!columns.contains('custom_background_path')) {
        await db.execute(
          'ALTER TABLE user_system_settings ADD COLUMN custom_background_path TEXT',
        );
      }
      if (!columns.contains('hide_logo')) {
        await db.execute(
          'ALTER TABLE user_system_settings ADD COLUMN hide_logo INTEGER DEFAULT 0',
        );
      }
      if (!columns.contains('hide_extension')) {
        await db.execute(
          'ALTER TABLE user_system_settings ADD COLUMN hide_extension INTEGER DEFAULT 0',
        );
      }
      if (!columns.contains('hide_parentheses')) {
        await db.execute(
          'ALTER TABLE user_system_settings ADD COLUMN hide_parentheses INTEGER DEFAULT 0',
        );
      }
      if (!columns.contains('hide_brackets')) {
        await db.execute(
          'ALTER TABLE user_system_settings ADD COLUMN hide_brackets INTEGER DEFAULT 0',
        );
      }
      if (!columns.contains('prefer_file_name')) {
        await db.execute(
          'ALTER TABLE user_system_settings ADD COLUMN prefer_file_name INTEGER DEFAULT 0',
        );
      }
      if (!columns.contains('custom_logo_path')) {
        await db.execute(
          'ALTER TABLE user_system_settings ADD COLUMN custom_logo_path TEXT',
        );
      }
    } catch (e) {
      _log.e('Minor fix ensuring system settings columns failed: $e');
      rethrow;
    }
  }

  /// Ensures required columns exist in user_screenscraper_config.
  Future<void> _ensureScreenScraperConfigColumns(DatabaseAdapter db) async {
    try {
      // Create table if missing.
      await db.execute('''
        CREATE TABLE IF NOT EXISTS user_screenscraper_config (
          id INTEGER PRIMARY KEY CHECK (id = 1),
          scrape_mode TEXT NOT NULL DEFAULT 'new_only',
          max_requests_per_minute INTEGER DEFAULT 10,
          timeout_seconds INTEGER DEFAULT 30,
          scrape_metadata INTEGER DEFAULT 1,
          scrape_images INTEGER DEFAULT 1,
          scrape_videos INTEGER DEFAULT 1,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
      ''');

      // Check for individual columns.
      final tableInfo = await db.rawQuery(
        'PRAGMA table_info(user_screenscraper_config)',
      );
      final columns = tableInfo.map((c) => c['name'].toString()).toList();

      if (!columns.contains('scrape_metadata')) {
        await db.execute(
          'ALTER TABLE user_screenscraper_config ADD COLUMN scrape_metadata INTEGER DEFAULT 1',
        );
      }
      if (!columns.contains('scrape_images')) {
        await db.execute(
          'ALTER TABLE user_screenscraper_config ADD COLUMN scrape_images INTEGER DEFAULT 1',
        );
      }
      if (!columns.contains('scrape_videos')) {
        await db.execute(
          'ALTER TABLE user_screenscraper_config ADD COLUMN scrape_videos INTEGER DEFAULT 1',
        );
      }
      if (!columns.contains('region_priority')) {
        await db.execute(
          "ALTER TABLE user_screenscraper_config ADD COLUMN region_priority TEXT DEFAULT '[\"wor\",\"us\",\"eu\",\"jp\",\"sp\",\"fr\",\"de\",\"it\",\"kr\",\"cn\"]'",
        );
      }
      if (!columns.contains('scrape_media_types')) {
        await db.execute(
          "ALTER TABLE user_screenscraper_config ADD COLUMN scrape_media_types TEXT DEFAULT '[\"fanart\",\"ss\",\"wheel\",\"box2D\",\"video\"]'",
        );
      }

      // Ensure default configuration entry exists.
      final config = await db.query(
        'user_screenscraper_config',
        where: 'id = 1',
      );
      if (config.isEmpty) {
        await db.insert('user_screenscraper_config', {
          'id': 1,
          'scrape_mode': 'new_only',
          'max_requests_per_minute': 10,
          'timeout_seconds': 30,
          'scrape_metadata': 1,
          'scrape_images': 1,
          'scrape_videos': 1,
        });
      }
    } catch (e) {
      _log.e('Error ensuring ScreenScraper configuration integrity: $e');
      rethrow;
    }
  }

  /// Creates initial database tables during first run.
  ///
  /// The schema, its seed data and the `user_version` stamp are committed as a
  /// single transaction. Dual-display devices run a second Flutter engine
  /// against this same database file (see `subDisplay()` in `lib/main.dart`),
  /// and that engine opens the file while first-run creation is still in
  /// flight. Committing the tables ahead of the stamp left a window in which it
  /// observed "tables exist but user_version is 0", which [_initDatabaseCore]
  /// reads as a legacy install and answers by replaying every migration from
  /// v1 over an already-current schema. Migration v5 then throws on
  /// `app_emulators.id`, a column migration v49 removes.
  Future<void> _onCreate(DatabaseAdapter db, int version) async {
    final stopwatch = Stopwatch()..start();

    try {
      // Create schema, seed it and stamp its version atomically.
      await db.transaction((txn) async {
        await _createAppTables(txn);
        await _createUserTables(txn);
        await _createRetroArchTables(txn);

        // Populate initial data.
        await _insertInitialData(db);

        // Stamp the version alongside the schema it describes, so no other
        // connection can read this database as an unversioned legacy install.
        await txn.execute('PRAGMA user_version = $version;');
      });

      // Initialize optimized indexes.
      await _createIndexes(db);

      // Defensive check for system columns.
      await _ensureAppSystemsColumns(db);

      stopwatch.stop();
    } catch (e, stackTrace) {
      _log.e(
        'Error creating initial database schema',
        error: e,
        stackTrace: stackTrace,
      );
      rethrow;
    }
  }

  /// Handles database schema upgrades.
  Future<void> _onUpgrade(
    DatabaseAdapter db,
    int oldVersion,
    int newVersion,
  ) async {
    for (int version = oldVersion + 1; version <= newVersion; version++) {
      await _migrateToVersion(db, version);
    }
  }

  /// Routes a version migration to the central migration manager.
  Future<void> _migrateToVersion(DatabaseAdapter db, int version) async {
    await SqliteMigrations.migrateToVersion(db.rawDb, version);
  }

  /// Handles database schema downgrades by recreating the schema.
  Future<void> _onDowngrade(
    DatabaseAdapter db,
    int oldVersion,
    int newVersion,
  ) async {
    await _recreateDatabase(db);
  }

  /// Completely drops and recreates the database schema.
  ///
  /// Foreign keys are disabled while dropping tables so that parent tables
  /// (e.g. [app_os], [app_systems]) can be removed even when child tables
  /// reference them. They are re-enabled before returning.
  Future<void> _recreateDatabase(DatabaseAdapter db) async {
    try {
      await db.execute('PRAGMA foreign_keys = OFF;');

      final tables = await db.rawQuery(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';",
      );

      for (final table in tables) {
        final tableName = table['name'].toString();
        await db.execute('DROP TABLE IF EXISTS $tableName;');
      }

      await _onCreate(db, _databaseVersion);
    } finally {
      await db.execute('PRAGMA foreign_keys = ON;');
    }
  }

  /// Creates internal application tables (systems, emulators, etc.).
  Future<void> _createAppTables(DatabaseExecutorAdapter db) async {
    const appTables = [
      '''
      CREATE TABLE IF NOT EXISTS app_os (
          id INTEGER PRIMARY KEY,
          name TEXT NOT NULL UNIQUE
      );
      ''',
      '''
      CREATE TABLE IF NOT EXISTS app_systems (
          id TEXT PRIMARY KEY,
          screenscraper_id INTEGER,
          ra_id INTEGER,
          ra_hash_algo TEXT,
          ra_hash_mode TEXT,
          real_name TEXT NOT NULL,
          short_name TEXT,
          folder_name TEXT NOT NULL UNIQUE,
          launch_date DATE,
          description TEXT,
          manufacturer TEXT,
          type TEXT,
          color1 TEXT,
          color2 TEXT,
          multidisc INTEGER NOT NULL DEFAULT 0,
          neosync_json TEXT
      );
      ''',
      '''
      CREATE TABLE IF NOT EXISTS app_system_folders (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          system_id TEXT NOT NULL,
          folder_name TEXT NOT NULL,
          FOREIGN KEY (system_id) REFERENCES app_systems(id) ON DELETE CASCADE,
          UNIQUE(system_id, folder_name)
      );
      ''',
      '''
      CREATE TABLE IF NOT EXISTS app_system_extensions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          system_id TEXT NOT NULL,
          extension TEXT NOT NULL,
          FOREIGN KEY (system_id) REFERENCES app_systems(id) ON DELETE CASCADE,
          UNIQUE(system_id, extension)
      );
      ''',
      '''
      CREATE TABLE IF NOT EXISTS app_emulators (
          unique_identifier TEXT NOT NULL,
          os_id INTEGER NOT NULL,
          system_id TEXT NOT NULL,
          name TEXT NOT NULL,
          is_standalone INTEGER NOT NULL DEFAULT 0,
          core_filename TEXT,
          is_default INTEGER NOT NULL DEFAULT 0,
          is_default_core INTEGER NOT NULL DEFAULT 0,
          is_default_standalone INTEGER NOT NULL DEFAULT 0,
          is_ra_compatible INTEGER NOT NULL DEFAULT 0,
          android_package_name TEXT,
          android_activity_name TEXT,
          neosync_slug TEXT,
          PRIMARY KEY (os_id, unique_identifier),
          FOREIGN KEY (os_id) REFERENCES app_os(id) ON DELETE CASCADE,
          FOREIGN KEY (system_id) REFERENCES app_systems(id) ON DELETE CASCADE
      );
      ''',
      '''
      CREATE TABLE IF NOT EXISTS user_custom_save_folders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        system_folder_name TEXT NOT NULL COLLATE NOCASE,
        emulator_slug TEXT NOT NULL,
        folder_path TEXT NOT NULL,
        UNIQUE(system_folder_name, emulator_slug)
      );
      ''',
    ];

    for (final sql in appTables) {
      await db.execute(sql.trim());
    }
  }

  /// Creates user-specific configuration and metadata tables.
  Future<void> _createUserTables(DatabaseExecutorAdapter db) async {
    const tables = [
      '''
      CREATE TABLE IF NOT EXISTS user_config (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        last_scan TEXT,
        game_view_mode TEXT DEFAULT 'list',
        system_view_mode TEXT DEFAULT 'grid',
        theme_name TEXT DEFAULT 'system',
        video_sound INTEGER DEFAULT 1,
        ra_user TEXT,
        show_game_info INTEGER DEFAULT 0,
        is_fullscreen INTEGER DEFAULT 1,
        bartop_exit_poweroff INTEGER DEFAULT 0,
        scan_on_startup INTEGER DEFAULT 1,
        ignore_hidden_files INTEGER DEFAULT 1,
        setup_completed INTEGER DEFAULT 0,
        hide_bottom_screen INTEGER DEFAULT 0,
        sfx_enabled INTEGER DEFAULT 1,
        sfx_volume REAL DEFAULT 0.75,
        system_sort_by TEXT DEFAULT 'alphabetical',
        collection_sort_by TEXT DEFAULT 'name',
        collection_sort_order TEXT DEFAULT 'asc',
        system_sort_order TEXT DEFAULT 'asc',
        app_language TEXT DEFAULT 'en',
        active_theme TEXT DEFAULT '',
        hide_recent_card INTEGER DEFAULT 0,
        recent_card_size TEXT DEFAULT 'default',
        -- Unused since the vertical action rail was removed. Kept so a fresh
        -- install matches the schema migration v103 left on upgraded devices.
        legend_hidden INTEGER DEFAULT 0,
        game_details_tab TEXT DEFAULT 'wheel',
        hide_tab_sync INTEGER DEFAULT 0,
        hide_tab_achievements INTEGER DEFAULT 0,
        hide_tab_scraper INTEGER DEFAULT 0,
        hide_tab_romm INTEGER DEFAULT 0,
        hide_tab_search INTEGER DEFAULT 0,
        active_sync_provider TEXT DEFAULT 'neosync',
        systems_version TEXT DEFAULT '',
        -- Generation stamp of the bundled RA seed asset that is currently
        -- loaded into app_ra_game_list. Read from the file's own header, so it
        -- moves whenever the asset is regenerated. See migration v138.
        ra_seed_stamp TEXT DEFAULT '',
        neostation_app_version TEXT DEFAULT '',
        auto_update_app INTEGER DEFAULT 1,
        auto_update_systems INTEGER DEFAULT 1,
        system_grid_columns TEXT DEFAULT 'M',
        game_grid_columns TEXT DEFAULT 'M',
        game_carousel_card_style TEXT DEFAULT 'fanart',
        use_12_hour_clock INTEGER DEFAULT 0,
        dock_apps TEXT,
        dock_enabled INTEGER DEFAULT 1,
        dock_slot_count INTEGER DEFAULT 3,
        now_playing_dim_delay INTEGER DEFAULT 3,
        now_playing_dim_level INTEGER DEFAULT 100,
        fanart_dim_level INTEGER DEFAULT 25,
        secondary_media_mode TEXT DEFAULT 'automatic',
        esde_folder_path TEXT DEFAULT '',
        show_achievements_badge INTEGER DEFAULT 0,
        show_cloud_sync_icon INTEGER DEFAULT 1,
        ra_match_on_startup INTEGER DEFAULT 0,
        subfolder_view_all INTEGER DEFAULT 0
      );
      ''',
      '''
      CREATE TABLE IF NOT EXISTS user_detected_systems (
        app_system_id TEXT NOT NULL,
        actual_folder_name TEXT,
        detected_at TEXT DEFAULT CURRENT_TIMESTAMP,
        is_hidden INTEGER DEFAULT 0,
        FOREIGN KEY (app_system_id) REFERENCES app_systems(id) ON DELETE CASCADE,
        UNIQUE(app_system_id)
      );
      ''',

      '''
      CREATE TABLE IF NOT EXISTS user_rom_folders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        path TEXT NOT NULL UNIQUE COLLATE NOCASE
      );
      ''',

      '''
      CREATE TABLE IF NOT EXISTS user_emulator_config (
        emulator_unique_id TEXT NOT NULL,
        emulator_path TEXT NOT NULL,
        is_user_default INTEGER DEFAULT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(emulator_unique_id)
      );
      ''',
      '''
      CREATE TABLE IF NOT EXISTS user_roms (
        app_system_id TEXT NOT NULL,
        app_emulator_unique_id TEXT,
        app_emulator_os_id INTEGER,
        app_alternative_emulators_id INTEGER,
        virtual_folder_name TEXT, -- DEPRECATED: Column to be removed in next migration
        filename TEXT NOT NULL,
        rom_path TEXT NOT NULL COLLATE NOCASE,
        ra_hash TEXT,
        -- ScreenScraper dump identity: md5 (ss_hash), crc32 and size of the ROM
        -- image itself. Distinct from ra_hash, which is RetroAchievements' own
        -- per-console transform and matches nothing else. See migration v135.
        ss_hash TEXT,
        rom_crc32 TEXT,
        rom_size INTEGER,
        rom_fingerprint_skipped TEXT,
        id_ra INTEGER,
        ra_match_source TEXT,
        ra_hash_skipped TEXT,
        is_favorite INTEGER DEFAULT 0,
        is_hidden INTEGER DEFAULT 0,
        play_time INTEGER DEFAULT 0,
        last_played TEXT,
        cloud_sync_enabled INTEGER DEFAULT 1,
        title_id TEXT,
        title_name TEXT,
        description TEXT,
        year TEXT,
        developer TEXT,
        publisher TEXT,
        genre TEXT,
        players TEXT,
        box2d_aspect_ratio TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (app_system_id) REFERENCES app_systems(id) ON DELETE CASCADE,
        FOREIGN KEY (app_emulator_os_id, app_emulator_unique_id) REFERENCES app_emulators(os_id, unique_identifier),
        UNIQUE(rom_path)
      );
      ''',
      '''
      CREATE TABLE IF NOT EXISTS user_screenscraper_credentials (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        username TEXT,
        password TEXT,
        user_id TEXT,
        level TEXT,
        contribution TEXT,
        maxthreads TEXT,
        requests_today INTEGER DEFAULT 0,
        max_requests_per_day INTEGER DEFAULT 0,
        requests_ko_today INTEGER DEFAULT 0,
        max_requests_ko_per_day INTEGER DEFAULT 0,
        max_download_speed INTEGER DEFAULT 0,
        visites INTEGER DEFAULT 0,
        last_visit TEXT,
        fav_region TEXT,
        preferred_language TEXT DEFAULT 'en',
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
      );
      ''',
      '''
      CREATE TABLE IF NOT EXISTS user_screenscraper_config (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        scrape_mode TEXT NOT NULL DEFAULT 'new_only',
        max_requests_per_minute INTEGER DEFAULT 10,
        timeout_seconds INTEGER DEFAULT 30,
        scrape_metadata INTEGER DEFAULT 1,
        scrape_images INTEGER DEFAULT 1,
        scrape_videos INTEGER DEFAULT 1,
        region_priority TEXT DEFAULT '["wor","us","eu","jp","sp","fr","de","it","kr","cn"]',
        scrape_media_types TEXT DEFAULT '["fanart","ss","wheel","box2D","video"]',
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
      );
      ''',
      '''
      CREATE TABLE IF NOT EXISTS user_screenscraper_system_metadata (
        app_system_id TEXT NOT NULL,
        system_name TEXT,
        manufacturer TEXT,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (app_system_id) REFERENCES app_systems(id) ON DELETE CASCADE,
        UNIQUE(app_system_id)
      );
      ''',
      SqliteMigrations.createUserRommConfigTableSql,
      '''
      CREATE TABLE IF NOT EXISTS user_screenscraper_metadata (
        app_system_id TEXT NOT NULL,
        filename TEXT NOT NULL,
        id_ra INTEGER,
        real_name TEXT,
        description_en TEXT,
        description_es TEXT,
        description_fr TEXT,
        description_de TEXT,
        description_it TEXT,
        description_pt TEXT,
        rating REAL,
        release_date TEXT,
        developer TEXT,
        publisher TEXT,
        genre TEXT,
        players TEXT,
        is_fully_scraped INTEGER DEFAULT 0,
        esde_media_subdir TEXT,
        esde_imported INTEGER DEFAULT 0,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (app_system_id) REFERENCES app_systems(id) ON DELETE CASCADE,
        UNIQUE(app_system_id, filename)
      );
      ''',
      '''
      CREATE TABLE IF NOT EXISTS user_screenscraper_system_config (
          app_system_id TEXT PRIMARY KEY,
          enabled BOOLEAN NOT NULL DEFAULT 1,
          FOREIGN KEY (app_system_id) REFERENCES app_systems(id) ON DELETE CASCADE
      );
      ''',
      '''
      CREATE TABLE IF NOT EXISTS user_system_settings (
        app_system_id TEXT NOT NULL,
        recursive_scan INTEGER DEFAULT 1,
        hide_extension INTEGER DEFAULT 1,
        hide_parentheses INTEGER DEFAULT 1,
        hide_brackets INTEGER DEFAULT 1,
        custom_background_path TEXT,
        custom_logo_path TEXT,
        hide_logo INTEGER DEFAULT 0,
        prefer_file_name INTEGER DEFAULT 0,
        subfolder_view INTEGER DEFAULT 0,
        esde_media_dir TEXT,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (app_system_id) REFERENCES app_systems(id) ON DELETE CASCADE,
        UNIQUE(app_system_id)
      );
      ''',
      SqliteMigrations.createAppNeoSyncStateTableSql,
      SqliteMigrations.createAppRommRomMapTableSql,
      SqliteMigrations.createAppRommPlaySessionsTableSql,
      SqliteMigrations.createAppRommPlaytimeStateTableSql,
      SqliteMigrations.createUserCollectionsTableSql,
      SqliteMigrations.createUserCollectionItemsTableSql,
    ];

    for (final sql in tables) {
      await db.execute(sql.trim());
    }
  }

  /// Creates tables dedicated to RetroAchievements game metadata.
  Future<void> _createRetroArchTables(DatabaseExecutorAdapter db) async {
    const raTables = [
      '''
      CREATE TABLE IF NOT EXISTS app_ra_game_list (
          id INTEGER,
          game_id INTEGER NOT NULL,
          title TEXT NOT NULL,
          console_id INTEGER NOT NULL,
          console_name TEXT NOT NULL,
          image_icon TEXT,
          num_achievements INTEGER NOT NULL DEFAULT 0,
          num_leaderboards INTEGER NOT NULL DEFAULT 0,
          points INTEGER NOT NULL DEFAULT 0,
          date_modified TEXT,
          forum_topic_id INTEGER,
          hash TEXT NOT NULL
      );
      ''',
    ];

    for (final sql in raTables) {
      await db.execute(sql.trim());
    }
  }

  /// Creates database indexes to optimize query performance across critical tables.
  Future<void> _createIndexes(DatabaseExecutorAdapter db) async {
    const indexes = [
      // Indexes for user_roms
      'CREATE INDEX IF NOT EXISTS idx_user_roms_app_system_id ON user_roms(app_system_id);',
      'CREATE INDEX IF NOT EXISTS idx_user_roms_ra_hash ON user_roms(ra_hash);',
      'CREATE INDEX IF NOT EXISTS idx_user_roms_ss_hash ON user_roms(ss_hash);',
      'CREATE INDEX IF NOT EXISTS idx_user_roms_rom_crc32 ON user_roms(rom_crc32);',
      'CREATE INDEX IF NOT EXISTS idx_user_roms_filename ON user_roms(filename);',
      'CREATE INDEX IF NOT EXISTS idx_user_roms_is_favorite ON user_roms(is_favorite);',
      'CREATE INDEX IF NOT EXISTS idx_user_roms_id_ra ON user_roms(id_ra);',

      // Indexes for user_screenscraper_metadata
      'CREATE INDEX IF NOT EXISTS idx_user_screenscraper_metadata_filename ON user_screenscraper_metadata(filename);',
      'CREATE INDEX IF NOT EXISTS idx_user_screenscraper_metadata_app_system_id ON user_screenscraper_metadata(app_system_id);',
      'CREATE INDEX IF NOT EXISTS idx_user_screenscraper_metadata_developer ON user_screenscraper_metadata(developer);',
      'CREATE INDEX IF NOT EXISTS idx_user_screenscraper_metadata_publisher ON user_screenscraper_metadata(publisher);',
      'CREATE INDEX IF NOT EXISTS idx_user_screenscraper_metadata_genre ON user_screenscraper_metadata(genre);',
      'CREATE INDEX IF NOT EXISTS idx_user_screenscraper_metadata_release_date ON user_screenscraper_metadata(release_date);',
      'CREATE INDEX IF NOT EXISTS idx_user_screenscraper_metadata_is_fully_scraped ON user_screenscraper_metadata(is_fully_scraped);',

      // Indexes for RetroAchievements
      'CREATE INDEX IF NOT EXISTS idx_app_ra_game_list_console_id ON app_ra_game_list(console_id);',
      'CREATE INDEX IF NOT EXISTS idx_app_ra_game_list_game_id ON app_ra_game_list(game_id);',
      'CREATE INDEX IF NOT EXISTS idx_app_ra_game_list_hash ON app_ra_game_list(hash);',
      'CREATE INDEX IF NOT EXISTS idx_app_ra_game_list_title ON app_ra_game_list(title);',

      // 3. Indexes for app_systems (including virtual systems >= 1000)
      'CREATE INDEX IF NOT EXISTS idx_app_systems_folder_name ON app_systems(folder_name);',

      // 4. Index for app_system_folders (optimizes alternative folder name lookups)
      'CREATE INDEX IF NOT EXISTS idx_system_folders_name ON app_system_folders(folder_name);',

      // 5. Index for user_emulator_config
      'CREATE INDEX IF NOT EXISTS idx_user_emulator_config_is_user_default ON user_emulator_config(is_user_default);',

      // 6. Index for app_neo_sync_state (provider-scoped)
      SqliteMigrations.createAppNeoSyncStateIndexSql,
      // 7. Index for app_romm_rom_map (RomM save-sync mapping)
      SqliteMigrations.createAppRommRomMapIndexSql,
      // 8. Index for app_romm_play_sessions (RomM playtime outbox)
      SqliteMigrations.createAppRommPlaySessionsIndexSql,
      // 9. Index for user_collection_items ("which collections is this ROM in?")
      SqliteMigrations.createUserCollectionItemsIndexSql,
    ];

    for (final sql in indexes) {
      await db.execute(sql);
    }
  }

  /// Populates the database with initial seed data from SQL assets.
  Future<void> _insertInitialData(DatabaseAdapter db) async {
    final stopwatch = Stopwatch()..start();

    try {
      await db.transaction((txn) async {
        await _ensureAppOsTable(txn);
        await txn.execute('''
          INSERT OR IGNORE INTO user_screenscraper_config (id, scrape_mode) VALUES (1, 'new_only')
        ''');
        await _executeSqlFileOptimized(
          txn,
          'assets/data/ra_insert.sql',
          'ra_insert',
        );

        // Insert "All Systems" virtual system for settings persistence
        await txn.execute('''
          INSERT OR IGNORE INTO app_systems (id, screenscraper_id, ra_id, real_name, folder_name, launch_date, description)
          VALUES ('all', 0, 0, 'All Systems', 'all', '2024-01-01',
                  'Collection of all systems available in NeoStation.')
        ''');
      });

      stopwatch.stop();
    } catch (e, stackTrace) {
      _log.e('Error inserting initial data', error: e, stackTrace: stackTrace);
      rethrow;
    }
  }

  Future<void> _executeSqlFileOptimized(
    DatabaseExecutorAdapter db,
    String assetPath,
    String fileName, {
    bool useTransaction = true,
  }) async {
    final content = await rootBundle.loadString(assetPath);
    final statements = _parseSqlStatements(content);

    if (statements.isEmpty) return;

    if (useTransaction && db is DatabaseAdapter) {
      // Use internal transaction for standalone calls
      final database = db;
      await database.transaction((txn) async {
        final batch = txn.batch(); // Simulates batching in adapter
        for (final statement in statements) {
          final trimmed = statement.trim();
          if (trimmed.isNotEmpty && !_isCommentOrEmpty(trimmed)) {
            batch.execute(trimmed);
          }
        }
        await batch.commit(noResult: true);
      });
    } else {
      // Use existing executor (transaction already in progress)
      final batch = db.batch();
      for (final statement in statements) {
        final trimmed = statement.trim();
        if (trimmed.isNotEmpty && !_isCommentOrEmpty(trimmed)) {
          batch.execute(trimmed);
        }
      }
      await batch.commit(noResult: true);
    }
  }

  /// Robustly parses individual SQL statements from a multi-statement string.
  List<String> _parseSqlStatements(String content) {
    final statements = <String>[];
    final buffer = StringBuffer();
    bool inSingleQuote = false;
    bool inDoubleQuote = false;
    bool inBlockComment = false;
    bool inLineComment = false;

    for (int i = 0; i < content.length; i++) {
      final char = content[i];
      final nextChar = i + 1 < content.length ? content[i + 1] : '';

      // Handle block comments
      if (!inSingleQuote && !inDoubleQuote && !inLineComment) {
        if (char == '/' && nextChar == '*') {
          inBlockComment = true;
          i++; // Skip next char
          continue;
        }
        if (char == '*' && nextChar == '/') {
          inBlockComment = false;
          i++; // Skip next char
          continue;
        }
      }

      if (inBlockComment) continue;

      // Handle line comments
      if (!inSingleQuote && !inDoubleQuote && char == '-' && nextChar == '-') {
        inLineComment = true;
        i++; // Skip next char
        continue;
      }
      if (inLineComment && char == '\n') {
        inLineComment = false;
        continue;
      }
      if (inLineComment) continue;

      // Handle quotes
      if (char == "'" && !inDoubleQuote) {
        inSingleQuote = !inSingleQuote;
      } else if (char == '"' && !inSingleQuote) {
        inDoubleQuote = !inDoubleQuote;
      }

      // Check for statement terminator outside of quotes and comments
      if (char == ';' && !inSingleQuote && !inDoubleQuote) {
        final statement = buffer.toString().trim();
        if (statement.isNotEmpty) {
          statements.add(statement);
        }
        buffer.clear();
        continue;
      }

      buffer.write(char);
    }

    // Add final statement if exists
    final lastStatement = buffer.toString().trim();
    if (lastStatement.isNotEmpty) {
      statements.add(lastStatement);
    }

    return statements;
  }

  /// Checks if a line is a comment or effectively empty.
  bool _isCommentOrEmpty(String line) {
    final trimmed = line.trim();
    return trimmed.isEmpty ||
        trimmed.startsWith('--') ||
        trimmed.startsWith('/*') ||
        trimmed == ';';
  }

  /// Resolves the absolute path for the database file.
  Future<String> _getDatabasePath() async {
    // Standardize logic using ConfigService for platform-agnostic storage.
    final userDataPath = await ConfigService.getUserDataPath();
    final dbDir = Directory(userDataPath);

    if (!await dbDir.exists()) {
      await dbDir.create(recursive: true);
    }

    return path.join(userDataPath, _databaseName);
  }

  /// Closes the database connection and resets state.
  Future<void> close() async {
    if (_database != null) {
      await _database!.close();
      _database = null;
      _initialized = false;
      _initCompleter = null; // Allow fresh initialization after close.
    }
  }

  /// Forces database recreation by deleting the existing file (for debugging).
  Future<void> resetDatabase() async {
    await close();

    final dbPath = await _getDatabasePath();
    final file = File(dbPath);
    if (await file.exists()) {
      await file.delete();
    }

    // Re-initialize
    _database = await _initDatabase();
  }

  // ==========================================
  // VALIDATION & DEBUG METHODS
  // ==========================================

  /// Validates the database integrity and schema health.
  Future<bool> validateDatabase() async {
    try {
      final db = await database;

      // Verify presence of critical tables
      final criticalTables = [
        'app_os',
        'app_system_extensions',
        'app_systems',
        'app_emulators',
        'user_config',
        'user_roms',
      ];

      for (final table in criticalTables) {
        final result = await db.rawQuery(
          "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
          [table],
        );
        if (result.isEmpty) {
          _log.e('Critical table missing: $table');
          return false;
        }
      }

      // Check referential integrity
      await db.execute('PRAGMA foreign_key_check;');

      // Run full integrity check
      final integrityResult = await db.rawQuery('PRAGMA integrity_check;');
      final integrityStatus = integrityResult.first['integrity_check']
          ?.toString();

      if (integrityStatus != 'ok') {
        _log.e('Database integrity compromised: $integrityStatus');
        return false;
      }

      return true;
    } catch (e, stackTrace) {
      _log.e('Error validating database', error: e, stackTrace: stackTrace);
      return false;
    }
  }

  /// Collects operational statistics and storage usage from the database.
  Future<Map<String, dynamic>> getDatabaseStats() async {
    try {
      final db = await database;

      final stats = <String, dynamic>{};

      // Record counts per table
      final tables = [
        'app_os',
        'app_systems',
        'app_system_extensions',
        'app_emulators',
        'user_roms',
        'user_detected_systems',
      ];

      for (final table in tables) {
        final result = await db.rawQuery(
          'SELECT COUNT(*) as count FROM $table',
        );
        stats['${table}_count'] =
            int.tryParse(result.first['count']?.toString() ?? '') ?? 0;
      }

      // Database file metrics
      final dbPath = await _getDatabasePath();
      final file = File(dbPath);
      if (await file.exists()) {
        stats['database_size_bytes'] = await file.length();
        stats['database_size_mb'] = (await file.length()) / (1024 * 1024);
      }

      // Engine version
      final sqliteVersion = await db.rawQuery(
        'SELECT sqlite_version() as version',
      );
      stats['sqlite_version'] = sqliteVersion.first['version'].toString();

      return stats;
    } catch (e, stackTrace) {
      _log.e('Error getting database stats', error: e, stackTrace: stackTrace);
      return {};
    }
  }

  // ==========================================
  // LEGACY COMPATIBILITY METHODS
  // ==========================================

  /// Static alias for [database] to maintain backward compatibility.
  static Future<DatabaseAdapter> getDatabase() async => instance.database;

  /// Static alias for [close].
  static Future<void> closeDatabase() => instance.close();

  /// Static alias for database initialization.
  static Future<DatabaseAdapter> initDatabase() async {
    return await instance.database;
  }

  /// Retrieves the absolute file path of the current database.
  static Future<String> getActualDatabasePath() async {
    return await instance._getDatabasePath();
  }

  /// Manually triggers schema creation from a custom script.
  static Future<void> createDatabaseFromScript(
    DatabaseAdapter db,
    int version,
  ) async {
    await instance._onCreate(db, version);
  }

  /// Executes a table creation script with optimized transaction handling.
  static Future<void> executeCreateScript(
    DatabaseAdapter db,
    String assetPath,
  ) async {
    await instance._executeSqlFileOptimized(
      db,
      assetPath,
      path.basename(assetPath),
    );
  }

  /// Executes a data insertion script optimized for batch performance.
  static Future<void> executeInsertScript(
    DatabaseAdapter db,
    String assetPath,
  ) async {
    await instance._executeSqlFileOptimized(
      db,
      assetPath,
      path.basename(assetPath),
    );
  }

  /// Executes an index creation script within an optimized transaction.
  static Future<void> executeIndexScript(
    DatabaseAdapter db,
    String assetPath,
  ) async {
    await instance._executeSqlFileOptimized(
      db,
      assetPath,
      path.basename(assetPath),
    );
  }

  /// Initializes essential user configuration records after schema creation.
  static Future<void> initializeUserData(DatabaseAdapter db) async {
    try {
      // Default initial configuration
      await db.insert('user_config', {
        'id': 1,
        'last_scan': null,
        'system_view_mode': 'grid',
        'theme_name': 'system',
        'video_sound': 1,
        'ra_user': null,
        'show_game_info': 0,
        'is_fullscreen': 1,
      });
    } catch (e) {
      _log.e('Error creating initial user configuration', error: e);
    }
  }

  // ==========================================
  // USER CONFIGURATION METHODS
  // ==========================================

  /// Retrieves the current user configuration record.
  static Future<Map<String, dynamic>?> getUserConfig() async {
    final db = await instance.database;
    final results = await db.query('user_config', limit: 1);

    if (results.isNotEmpty) {
      return results.first;
    }
    return null;
  }

  /// Retrieves all configured ROM root directories.
  static Future<List<String>> getUserRomFolders() async {
    final db = await instance.database;
    final results = await db.query('user_rom_folders', orderBy: 'id ASC');
    return results.map((row) => row['path'].toString()).toList();
  }

  /// Rebuilds Android ROM roots from existing library entries when a previous
  /// migration or interrupted save left [user_rom_folders] empty. Both SAF tree
  /// URIs and traditional paths are supported so the library remains usable
  /// while the user moves from legacy storage access to SAF.
  static Future<List<String>> recoverRomFoldersFromStoredRoms() async {
    final db = await instance.database;
    final rows = await db.rawQuery('''
      SELECT ur.rom_path, s.folder_name
      FROM user_roms ur
      JOIN app_systems s ON s.id = ur.app_system_id
      WHERE ur.rom_path IS NOT NULL AND ur.rom_path != ''
    ''');

    final roots = <String>{};
    for (final row in rows) {
      final romPath = row['rom_path']?.toString() ?? '';
      final systemFolder = row['folder_name']?.toString() ?? '';
      if (romPath.isEmpty || systemFolder.isEmpty) continue;

      // SAF files retain their selected tree URI before the document segment.
      final documentIndex = romPath.indexOf('/document/');
      if (romPath.startsWith('content://') && documentIndex > 0) {
        roots.add(romPath.substring(0, documentIndex));
        continue;
      }

      // Legacy paths generally look like /root/<system>/<rom>. Derive the
      // root only when the stored system folder appears as a full path segment.
      final normalizedPath = romPath.replaceAll('\\', '/');
      final lowerPath = normalizedPath.toLowerCase();
      final marker = '/${systemFolder.toLowerCase()}/';
      final folderIndex = lowerPath.lastIndexOf(marker);
      if (folderIndex > 0) {
        roots.add(normalizedPath.substring(0, folderIndex));
      }
    }

    return roots.toList()..sort();
  }

  /// Persists a complete list of ROM directories, replacing existing ones.
  ///
  /// An empty list is ignored while folders are already configured. No caller
  /// legitimately clears the table this way — removing a folder has its own
  /// targeted API ([removeRomFolder]) — so an empty list means the config
  /// object never carried the folders, not that the user removed them. Acting
  /// on it is silently destructive: the next scan runs as a fast scan, which
  /// prunes every system and ROM row, which in turn leaves
  /// [recoverRomFoldersFromStoredRoms] nothing to derive a root from.
  static Future<void> saveUserRomFolders(List<String> folders) async {
    final db = await instance.database;
    // Deduplicated because `path` is UNIQUE: a caller that appended a folder it
    // already held would otherwise collide with itself mid-transaction.
    final paths = folders
        .where((folder) => folder.isNotEmpty)
        .toSet()
        .toList(growable: false);

    if (paths.isEmpty) {
      final rows = await db.rawQuery(
        'SELECT COUNT(*) AS count FROM user_rom_folders',
      );
      final existing = rows.isEmpty ? 0 : (rows.first['count'] as int?) ?? 0;
      if (existing > 0) {
        _log.w(
          'saveUserRomFolders called with an empty list while $existing ROM '
          'folder(s) are configured - keeping them. Use removeRomFolder() to '
          'remove one.',
        );
        return;
      }
    }

    await db.transaction((txn) async {
      await txn.delete('user_rom_folders');
      for (final folder in paths) {
        await txn.insert('user_rom_folders', {
          'path': folder,
        }, conflictAlgorithm: ConflictAlgorithm.ignore);
      }
    });
  }

  /// Registers a new ROM directory.
  static Future<void> addRomFolder(String folderPath) async {
    if (folderPath.isEmpty) return;
    final db = await instance.database;
    await db.insert('user_rom_folders', {
      'path': folderPath,
    }, conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  /// Removes a ROM directory from configuration.
  static Future<void> removeRomFolder(String folderPath) async {
    final db = await instance.database;
    await db.delete(
      'user_rom_folders',
      where: 'path = ?',
      whereArgs: [folderPath],
    );
  }

  /// Deletes all ROM records associated with a specific directory prefix.
  static Future<int> deleteRomsByFolderPath(String folderPath) async {
    final db = await instance.database;

    // Remove ROM entries where the path starts with the specified folder.
    // Handles both SAF URI separators (/) and Windows path separators (\).
    return await db.delete(
      'user_roms',
      where: 'rom_path LIKE ? OR rom_path LIKE ? OR rom_path = ?',
      whereArgs: ['$folderPath/%', '$folderPath\\%', folderPath],
    );
  }

  /// Permanently deletes a single game and its metadata from the database.
  static Future<void> deleteGame(String appSystemId, String filename) async {
    final db = await instance.database;
    await db.delete(
      'user_screenscraper_metadata',
      where: 'app_system_id = ? AND filename = ?',
      whereArgs: [appSystemId, filename],
    );
    await db.delete(
      'user_roms',
      where: 'app_system_id = ? AND filename = ?',
      whereArgs: [appSystemId, filename],
    );
  }

  static Future<void> saveUserConfig({
    String? lastScan,
    String? gameViewMode,
    String? systemViewMode,
    String? themeName,
    int? videoSound,
    String? raUser,
    int? showGameInfo,
    int? isFullscreen,
    int? bartopExitPoweroff,
    int? scanOnStartup,
    int? ignoreHiddenFiles,
    int? setupCompleted,
    int? hideBottomScreen,
    int? sfxEnabled,
    double? sfxVolume,
    int? use12HourClock,
    String? systemSortBy,
    String? systemSortOrder,
    String? collectionSortBy,
    String? collectionSortOrder,
    String? appLanguage,
    String? activeTheme,
    int? hideRecentCard,
    String? recentCardSize,
    String? gameDetailsTab,
    int? hideTabSync,
    int? hideTabAchievements,
    int? hideTabScraper,
    int? hideTabRomm,
    int? hideTabSearch,
    String? activeSyncProvider,
    String? systemsVersion,
    String? raSeedStamp,
    String? neostationAppVersion,
    int? autoUpdateApp,
    int? autoUpdateSystems,
    String? systemGridColumns,
    String? gameGridColumns,
    String? gameCarouselCardStyle,
    String? dockApps,
    int? dockEnabled,
    int? dockSlotCount,
    int? nowPlayingDimDelay,
    int? nowPlayingDimLevel,
    int? fanartDimLevel,
    String? secondaryMediaMode,
    String? esdeFolderPath,
    int? showAchievementsBadge,
    int? showCloudSyncIcon,
    int? raMatchOnStartup,
    int? subfolderViewAll,
  }) async {
    final db = await instance.database;

    // Only the fields this call was actually given. Writing just these columns
    // is what makes concurrent writers safe: this used to read the whole row,
    // patch it, and write every column back, so any writer whose read landed
    // before another writer's write silently reverted it. That cost users their
    // theme (a settings toggle rewriting theme_name from its own stale read),
    // and the same window is open on active_theme, systems_version and ra_user
    // — all of which have a single dedicated setter and no other writer that
    // would restore them. An UPDATE of the named columns leaves every other
    // column alone, so there is nothing to lose.
    final Map<String, Object?> updates = {};

    // Update fields if provided
    if (lastScan != null) updates['last_scan'] = lastScan;
    if (gameViewMode != null) updates['game_view_mode'] = gameViewMode;
    if (systemViewMode != null) updates['system_view_mode'] = systemViewMode;
    if (themeName != null) updates['theme_name'] = themeName;
    if (videoSound != null) updates['video_sound'] = videoSound;
    if (raUser != null) updates['ra_user'] = raUser;
    if (showGameInfo != null) updates['show_game_info'] = showGameInfo;
    if (isFullscreen != null) updates['is_fullscreen'] = isFullscreen;
    if (bartopExitPoweroff != null) {
      updates['bartop_exit_poweroff'] = bartopExitPoweroff;
    }
    if (scanOnStartup != null) {
      updates['scan_on_startup'] = scanOnStartup;
    }
    if (ignoreHiddenFiles != null) {
      updates['ignore_hidden_files'] = ignoreHiddenFiles;
    }
    if (setupCompleted != null) {
      updates['setup_completed'] = setupCompleted;
    }
    if (hideBottomScreen != null) {
      updates['hide_bottom_screen'] = hideBottomScreen;
    }
    if (sfxEnabled != null) {
      updates['sfx_enabled'] = sfxEnabled;
    }
    if (sfxVolume != null) {
      updates['sfx_volume'] = sfxVolume;
    }
    if (use12HourClock != null) {
      updates['use_12_hour_clock'] = use12HourClock;
    }
    if (systemSortBy != null) {
      updates['system_sort_by'] = systemSortBy;
    }
    if (systemSortOrder != null) {
      updates['system_sort_order'] = systemSortOrder;
    }
    if (collectionSortBy != null) {
      updates['collection_sort_by'] = collectionSortBy;
    }
    if (collectionSortOrder != null) {
      updates['collection_sort_order'] = collectionSortOrder;
    }
    if (appLanguage != null) {
      updates['app_language'] = appLanguage;
    }
    if (activeTheme != null) {
      updates['active_theme'] = activeTheme;
    }
    if (hideRecentCard != null) {
      updates['hide_recent_card'] = hideRecentCard;
    }
    if (recentCardSize != null) {
      updates['recent_card_size'] = recentCardSize;
    }
    if (gameDetailsTab != null) {
      updates['game_details_tab'] = gameDetailsTab;
    }
    if (hideTabSync != null) {
      updates['hide_tab_sync'] = hideTabSync;
    }
    if (hideTabAchievements != null) {
      updates['hide_tab_achievements'] = hideTabAchievements;
    }
    if (hideTabScraper != null) {
      updates['hide_tab_scraper'] = hideTabScraper;
    }
    if (hideTabRomm != null) {
      updates['hide_tab_romm'] = hideTabRomm;
    }
    if (hideTabSearch != null) {
      updates['hide_tab_search'] = hideTabSearch;
    }
    if (activeSyncProvider != null) {
      updates['active_sync_provider'] = activeSyncProvider;
    }
    if (raSeedStamp != null) {
      updates['ra_seed_stamp'] = raSeedStamp;
    }
    if (systemsVersion != null) {
      updates['systems_version'] = systemsVersion;
    }
    if (neostationAppVersion != null) {
      updates['neostation_app_version'] = neostationAppVersion;
    }
    if (autoUpdateApp != null) {
      updates['auto_update_app'] = autoUpdateApp;
    }
    if (autoUpdateSystems != null) {
      updates['auto_update_systems'] = autoUpdateSystems;
    }
    if (systemGridColumns != null) {
      updates['system_grid_columns'] = systemGridColumns;
    }
    if (gameGridColumns != null) {
      updates['game_grid_columns'] = gameGridColumns;
    }
    if (gameCarouselCardStyle != null) {
      updates['game_carousel_card_style'] = gameCarouselCardStyle;
    }
    if (dockApps != null) {
      updates['dock_apps'] = dockApps;
    }
    if (dockEnabled != null) {
      updates['dock_enabled'] = dockEnabled;
    }
    if (dockSlotCount != null) {
      updates['dock_slot_count'] = dockSlotCount;
    }
    if (nowPlayingDimDelay != null) {
      updates['now_playing_dim_delay'] = nowPlayingDimDelay;
    }
    if (nowPlayingDimLevel != null) {
      updates['now_playing_dim_level'] = nowPlayingDimLevel;
    }
    if (fanartDimLevel != null) {
      updates['fanart_dim_level'] = fanartDimLevel;
    }
    if (secondaryMediaMode != null) {
      updates['secondary_media_mode'] = secondaryMediaMode;
    }
    if (esdeFolderPath != null) {
      updates['esde_folder_path'] = esdeFolderPath;
    }
    if (raMatchOnStartup != null) {
      updates['ra_match_on_startup'] = raMatchOnStartup;
    }
    if (subfolderViewAll != null) {
      updates['subfolder_view_all'] = subfolderViewAll;
    }

    if (showAchievementsBadge != null) {
      updates['show_achievements_badge'] = showAchievementsBadge;
    }

    if (showCloudSyncIcon != null) {
      updates['show_cloud_sync_icon'] = showCloudSyncIcon;
    }

    // Both statements run in one transaction. Apart alone they can straddle a
    // concurrent [clearUserData], which deletes the row: the insert would run
    // before the delete and the update after it, matching nothing and
    // discarding the user's setting with no error (saves are fire-and-forget in
    // places — see mutators.dart). The old single INSERT OR REPLACE couldn't
    // lose a write that way, so the transaction restores what the rewrite gave
    // up.
    await db.transaction((txn) async {
      // The row is a singleton (id = 1, enforced by CHECK since migration v24).
      // Create it if this is the first write — OR IGNORE so a concurrent caller
      // that got there first isn't reset to column defaults — then set only the
      // columns this call named.
      await txn.insert('user_config', {
        'id': 1,
      }, conflictAlgorithm: ConflictAlgorithm.ignore);

      if (updates.isEmpty) return;

      // No WHERE: on a singleton table this is the same row, and it keeps the
      // write from assuming an id the read side doesn't ask for either
      // ([getUserConfig] just takes the first row). If a stray row ever did
      // exist, every row converges instead of the reader and writer disagreeing
      // about which one is live.
      await txn.update('user_config', updates);
    });
  }

  /// Returns folder names of systems the user has hidden
  static Future<Set<String>> getHiddenSystems() async {
    final db = await instance.database;
    final results = await db.rawQuery(
      'SELECT actual_folder_name FROM user_detected_systems WHERE is_hidden = 1',
    );
    return results.map((r) => r['actual_folder_name'].toString()).toSet();
  }

  /// Sets a system's hidden state by its folder name
  static Future<void> setSystemHidden(String folderName, bool isHidden) async {
    final db = await instance.database;
    await db.rawUpdate(
      'UPDATE user_detected_systems SET is_hidden = ? WHERE actual_folder_name = ?',
      [isHidden ? 1 : 0, folderName],
    );
  }

  /// Checks if recursive scan is enabled for a system.
  static Future<bool> getSystemRecursiveScan(String systemId) async {
    final db = await instance.database;
    final results = await db.query(
      'user_system_settings',
      where: 'app_system_id = ?',
      whereArgs: [systemId],
    );

    if (results.isEmpty) return false;
    // Check the 'recursive_scan' column value
    return (int.tryParse(results.first['recursive_scan']?.toString() ?? '1') ??
            1) ==
        1;
  }

  /// Sets whether recursive scan is enabled for a system.
  static Future<void> setSystemRecursiveScan(
    String systemId,
    bool enabled,
  ) async {
    await _updateSystemSetting(systemId, 'recursive_scan', enabled ? 1 : 0);
  }

  /// Sets whether to hide the file extension.
  static Future<void> setSystemHideExtension(
    String systemId,
    bool enabled,
  ) async {
    await _updateSystemSetting(systemId, 'hide_extension', enabled ? 1 : 0);
  }

  static Future<void> setSystemHideParentheses(
    String systemId,
    bool enabled,
  ) async {
    await _updateSystemSetting(systemId, 'hide_parentheses', enabled ? 1 : 0);
  }

  static Future<void> setSystemHideBrackets(
    String systemId,
    bool enabled,
  ) async {
    await _updateSystemSetting(systemId, 'hide_brackets', enabled ? 1 : 0);
  }

  static Future<void> setSystemPreferFileName(
    String systemId,
    bool enabled,
  ) async {
    await _updateSystemSetting(systemId, 'prefer_file_name', enabled ? 1 : 0);
  }

  /// Sets whether ROM subfolders are shown as navigable folders in the game list.
  static Future<void> setSystemSubfolderView(
    String systemId,
    bool enabled,
  ) async {
    await _updateSystemSetting(systemId, 'subfolder_view', enabled ? 1 : 0);
  }

  /// The `NOT IN (?, ?, ...)` fragment and arguments that keep a statement off
  /// the systems the subfolder view cannot apply to.
  static (String, List<Object?>) get _nonVirtualSystemsFilter {
    final names = SystemFolderNames.subfolderViewExcluded.toList();
    final holes = List.filled(names.length, '?').join(', ');
    return ('s.folder_name NOT IN ($holes)', names);
  }

  /// How many systems currently carry a `subfolder_view` of their own, i.e. one
  /// that differs from [globalValue], the last global choice.
  ///
  /// This is what the settings screen reports before the global toggle
  /// overwrites them. Counting rows that *deviate* rather than rows that will
  /// change is the whole point: on a plain global flip every system moves
  /// together, and saying so would be noise, not information.
  ///
  /// A system with no settings row reads as off, exactly as the game list reads
  /// it, hence the LEFT JOIN and the COALESCE.
  static Future<int> countSubfolderViewOverrides(bool globalValue) async {
    final db = await instance.database;
    final (filter, args) = _nonVirtualSystemsFilter;

    final result = await db.rawQuery(
      'SELECT COUNT(*) AS c FROM app_systems s '
      'LEFT JOIN user_system_settings ss ON s.id = ss.app_system_id '
      'WHERE $filter AND COALESCE(ss.subfolder_view, 0) != ?',
      [...args, globalValue ? 1 : 0],
    );

    return int.tryParse(result.first['c']?.toString() ?? '0') ?? 0;
  }

  /// Applies "Show Subfolders" to every system in one pass, for the global
  /// toggle in Settings > General.
  ///
  /// Systems the user has never opened the settings dialog for have no
  /// [user_system_settings] row at all, so the stamp has to create one before
  /// it can update it. The inserted row names only `subfolder_view`: every
  /// other column falls back to its table default, which is exactly what the
  /// absent row already read as, so this adds no behaviour of its own.
  ///
  /// Virtual systems are skipped ([SystemFolderNames.subfolderViewExcluded]).
  /// The game list never reads the flag for them, so writing one would only be
  /// a value waiting to be believed by some later change.
  static Future<void> setSubfolderViewForAllSystems(bool enabled) async {
    final db = await instance.database;
    final value = enabled ? 1 : 0;
    final now = DateTime.now().toIso8601String();
    final (filter, args) = _nonVirtualSystemsFilter;

    await db.transaction((txn) async {
      await txn.rawInsert(
        'INSERT INTO user_system_settings '
        '(app_system_id, subfolder_view, updated_at) '
        'SELECT s.id, ?, ? FROM app_systems s '
        'WHERE $filter AND NOT EXISTS ('
        'SELECT 1 FROM user_system_settings ss WHERE ss.app_system_id = s.id)',
        [value, now, ...args],
      );
      await txn.rawUpdate(
        'UPDATE user_system_settings SET subfolder_view = ?, updated_at = ? '
        'WHERE app_system_id IN '
        '(SELECT s.id FROM app_systems s WHERE $filter)',
        [value, now, ...args],
      );
    });

    // The cached models carry the old per-system flag, and the settings dialog
    // reads them.
    _cachedSystems = null;
  }

  /// Retrieves the complete configuration for a system.
  static Future<Map<String, dynamic>> getSystemSettings(String systemId) async {
    final db = await instance.database;
    final results = await db.query(
      'user_system_settings',
      where: 'app_system_id = ?',
      whereArgs: [systemId],
      limit: 1,
    );

    if (results.isNotEmpty) {
      return results.first;
    }
    return {};
  }

  static Future<void> _updateSystemSetting(
    String systemId,
    String column,
    dynamic value,
  ) async {
    final db = await instance.database;
    await db.transaction((txn) async {
      // 1. Get existing record
      final existing = await txn.query(
        'user_system_settings',
        where: 'app_system_id = ?',
        whereArgs: [systemId],
        limit: 1,
      );

      final Map<String, dynamic> data = existing.isNotEmpty
          ? Map.from(existing.first)
          : {'app_system_id': systemId};

      data[column] = value;
      data['updated_at'] = DateTime.now().toIso8601String();

      await txn.insert(
        'user_system_settings',
        data,
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    });

    // Invalidate the systems cache so subsequent reads reflect the updated
    // setting (e.g. hide_logo) instead of returning a stale cached model.
    _cachedSystems = null;
  }

  /// Sets custom images for a system.
  static Future<void> setSystemCustomImages(
    String systemId, {
    String? backgroundPath,
    String? logoPath,
  }) async {
    final db = await instance.database;

    await db.transaction((txn) async {
      final existing = await txn.query(
        'user_system_settings',
        where: 'app_system_id = ?',
        whereArgs: [systemId],
        limit: 1,
      );

      final Map<String, dynamic> data = existing.isNotEmpty
          ? Map.from(existing.first)
          : {};

      data['app_system_id'] = systemId;
      data['updated_at'] = DateTime.now().toIso8601String();

      if (backgroundPath != null) {
        data['custom_background_path'] = backgroundPath;
      }
      if (logoPath != null) {
        data['custom_logo_path'] = logoPath;
      }

      await txn.insert(
        'user_system_settings',
        data,
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    });
  }

  /// Retrieves the system view mode.
  static Future<String> getSystemViewMode() async {
    final config = await getUserConfig();
    return config?['system_view_mode']?.toString() ?? 'grid';
  }

  /// Updates the system view mode.
  static Future<void> updateSystemViewMode(String mode) async {
    await saveUserConfig(systemViewMode: mode);
  }

  /// Updates the theme name.
  static Future<void> updateThemeName(String themeName) async {
    await saveUserConfig(themeName: themeName);
  }

  /// Retrieves the current theme name.
  static Future<String> getThemeName() async {
    final config = await getUserConfig();
    return config?['theme_name']?.toString() ?? 'system';
  }

  /// Retrieves the active asset theme (neostation-assets).
  static Future<String> getActiveTheme() async {
    final config = await getUserConfig();
    return config?['active_theme']?.toString() ?? '';
  }

  /// Updates the active asset theme.
  static Future<void> updateActiveTheme(String themeFolder) async {
    await saveUserConfig(activeTheme: themeFolder);
  }

  /// Retrieves the locally stored systems manifest version.
  static Future<String> getSystemsVersion() async {
    final config = await getUserConfig();
    return config?['systems_version']?.toString() ?? '';
  }

  /// Persists the systems manifest version after a successful update.
  static Future<void> updateSystemsVersion(String version) async {
    await saveUserConfig(systemsVersion: version);
  }

  /// Retrieves the RA seed generation stamp currently loaded into
  /// `app_ra_game_list`, or `''` if the seed has never run.
  static Future<String> getRaSeedStamp() async {
    final config = await getUserConfig();
    return config?['ra_seed_stamp']?.toString() ?? '';
  }

  /// Persists the RA seed generation stamp after a successful re-seed.
  static Future<void> updateRaSeedStamp(String stamp) async {
    await saveUserConfig(raSeedStamp: stamp);
  }

  /// Retrieves the Neostation app version recorded at last startup.
  static Future<String> getNeostationAppVersion() async {
    final config = await getUserConfig();
    return config?['neostation_app_version']?.toString() ?? '';
  }

  /// Persists the current Neostation app version.
  static Future<void> updateNeostationAppVersion(String version) async {
    await saveUserConfig(neostationAppVersion: version);
  }

  /// Updates the video/sound configuration setting.
  static Future<void> updateVideoSound(int value) async {
    await saveUserConfig(videoSound: value);
  }

  /// Updates the RetroAchievements username.
  static Future<void> updateRAUser(String user) async {
    await saveUserConfig(raUser: user);
  }

  /// Updates the bartop power-off setting upon exit.
  static Future<void> updateBartopExitPoweroff(int value) async {
    await saveUserConfig(bartopExitPoweroff: value);
  }

  /// Configures whether the application should automatically scan for games on startup.
  static Future<void> updateScanOnStartup(int value) async {
    await saveUserConfig(scanOnStartup: value);
  }

  /// Configures whether the startup scan is followed by a RetroAchievements
  /// match pass over the ROMs it added.
  static Future<void> updateRaMatchOnStartup(int value) async {
    await saveUserConfig(raMatchOnStartup: value);
  }

  // ==========================================
  // SYSTEM DETECTION METHODS
  // ==========================================

  /// Retrieves all gaming systems detected on the current hardware or configured by the user.
  static Future<List<SystemModel>> getUserDetectedSystems() async {
    final db = await instance.database;

    final results = await db.rawQuery('''
      SELECT s.*, uds.actual_folder_name,
             (SELECT COUNT(*) FROM user_roms ur WHERE ur.app_system_id = s.id AND ur.is_hidden = 0) as rom_count,
             ss.recursive_scan,
             ss.hide_extension,
             ss.hide_parentheses,
             ss.hide_brackets,
             ss.custom_background_path,
             ss.custom_logo_path,
             ss.hide_logo,
             ss.prefer_file_name,
             ss.subfolder_view
      FROM app_systems s
      LEFT JOIN user_detected_systems uds ON s.id = uds.app_system_id
      LEFT JOIN user_system_settings ss ON s.id = ss.app_system_id
      WHERE uds.app_system_id IS NOT NULL
         OR (SELECT COUNT(*) FROM user_roms ur WHERE ur.app_system_id = s.id) > 0
         OR (s.folder_name = 'favorites' AND (SELECT COUNT(*) FROM user_roms WHERE is_favorite = 1 AND app_system_id != 'music') > 0)
      ORDER BY s.real_name ASC
    ''');

    return await _enrichSystemsWithFoldersAndExtensions(db, results);
  }

  /// Enriches raw system records with associated folder aliases and valid file extensions.
  static Future<List<SystemModel>> _enrichSystemsWithFoldersAndExtensions(
    DatabaseExecutorAdapter db,
    List<Map<String, Object?>> results,
  ) async {
    if (results.isEmpty) return [];

    // 1. Fetch all folder mappings in a single query to minimize IO overhead.
    final folderResults = await db.query('app_system_folders');
    final Map<String, List<String>> folderMap = {};
    for (final row in folderResults) {
      final sid = row['system_id'].toString();
      folderMap.putIfAbsent(sid, () => []).add(row['folder_name'].toString());
    }

    // 2. Fetch all extension mappings in a single query.
    final extensionResults = await db.query('app_system_extensions');
    final Map<String, List<String>> extensionMap = {};
    for (final row in extensionResults) {
      final sid = row['system_id'].toString();
      extensionMap.putIfAbsent(sid, () => []).add(row['extension'].toString());
    }

    // 3. Map records to SystemModel objects, injecting resolved metadata.
    return results.map((row) {
      final sid = row['id'].toString();
      final Map<String, dynamic> mutableRow = Map.from(row);

      mutableRow['folders'] = folderMap[sid] ?? [];
      mutableRow['extensions'] = extensionMap[sid] ?? [];

      // Parse cloud sync JSON configuration if available.
      final neosyncJson = row['neosync_json']?.toString();
      if (neosyncJson != null && neosyncJson.isNotEmpty) {
        try {
          mutableRow['neosync'] = json.decode(neosyncJson);
        } catch (e) {
          // Silent failure for malformed JSON.
        }
      }

      return SystemModel.fromJson(mutableRow);
    }).toList();
  }

  /// Registers a detected system folder.
  static Future<void> addDetectedSystem(
    String systemId,
    String actualFolderName,
  ) async {
    final db = await instance.database;
    await db.insert('user_detected_systems', {
      'app_system_id': systemId,
      'actual_folder_name': actualFolderName,
    }, conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  /// Removes a system from the detected systems registry.
  static Future<void> removeDetectedSystem(String systemId) async {
    final db = await instance.database;
    await db.delete(
      'user_detected_systems',
      where: 'app_system_id = ?',
      whereArgs: [systemId],
    );
  }

  /// Synchronizes the list of detected systems based on a collection of physical folder names.
  static Future<void> updateDetectedSystems(List<String> folderNames) async {
    final db = await instance.database;

    await db.transaction((txn) async {
      // Preserve hidden states before wiping the table.
      final hiddenRows = await txn.query(
        'user_detected_systems',
        columns: ['actual_folder_name'],
        where: 'is_hidden = 1',
      );
      final hiddenFolders = hiddenRows
          .map((r) => r['actual_folder_name'] as String)
          .toSet();

      // Clear previous detections to avoid stale or duplicate entries.
      await txn.delete('user_detected_systems');

      for (final folder in folderNames) {
        // 1. Attempt primary folder name match (case-insensitive).
        var sys = await txn.query(
          'app_systems',
          columns: ['id'],
          where: 'folder_name = ? COLLATE NOCASE',
          whereArgs: [folder],
          limit: 1,
        );

        // 2. If not found, search within alternative folder aliases.
        if (sys.isEmpty) {
          sys = await txn.rawQuery(
            'SELECT system_id as id FROM app_system_folders WHERE folder_name = ? COLLATE NOCASE LIMIT 1',
            [folder],
          );
        }

        if (sys.isNotEmpty) {
          await txn.insert('user_detected_systems', {
            'app_system_id': sys.first['id'],
            'actual_folder_name': folder,
            'is_hidden': hiddenFolders.contains(folder) ? 1 : 0,
          }, conflictAlgorithm: ConflictAlgorithm.replace);
        }
      }
    });
  }

  /// Resolves a [SystemModel] based on its physical folder name.
  static Future<SystemModel> getSystemByFolderName(String folderName) async {
    // Attempt cache hit before hitting the database.
    final systems = _cachedSystems ?? await loadSystemsFromDb();

    try {
      SystemModel system = systems.firstWhere((s) {
        final lowerInput = folderName.toLowerCase();

        // Match primary folder name.
        if (s.folderName.toLowerCase() == lowerInput) return true;

        // Match alternative aliases.
        if (s.folders.any((f) => f.toLowerCase() == lowerInput)) return true;

        // Fallback for legacy normalization (stripping spaces).
        if (s.folderName.toLowerCase().replaceAll(' ', '') ==
            lowerInput.replaceAll(' ', '')) {
          return true;
        }

        return false;
      });

      // Synchronize exact ROM count from persistent storage. Hidden games are
      // left out so the count always matches the list the user can see; the
      // callers that decide whether a system still exists ask for the raw count
      // instead ([getRomCountForSystem]).
      final romCount = await getVisibleRomCountForSystem(system.id!);
      system = system.copyWith(romCount: romCount);

      // Enrich with user-specific system overrides.
      final db = await instance.database;
      final settings = await db.query(
        'user_system_settings',
        columns: [
          'recursive_scan',
          'hide_extension',
          'hide_parentheses',
          'hide_brackets',
          'custom_background_path',
          'custom_logo_path',
          'hide_logo',
          'prefer_file_name',
          'subfolder_view',
        ],
        where: 'app_system_id = ?',
        whereArgs: [system.id],
      );

      if (settings.isNotEmpty) {
        final row = settings.first;
        return system.copyWith(
          recursiveScan:
              (int.tryParse(row['recursive_scan']?.toString() ?? '1') ?? 1) ==
              1,
          hideExtension:
              (int.tryParse(row['hide_extension']?.toString() ?? '1') ?? 1) ==
              1,
          hideParentheses:
              (int.tryParse(row['hide_parentheses']?.toString() ?? '1') ?? 1) ==
              1,
          hideBrackets:
              (int.tryParse(row['hide_brackets']?.toString() ?? '1') ?? 1) == 1,
          customBackgroundPath: row['custom_background_path']?.toString(),
          customLogoPath: row['custom_logo_path']?.toString(),
          hideLogo:
              (int.tryParse(row['hide_logo']?.toString() ?? '0') ?? 0) == 1,
          preferFileName:
              (int.tryParse(row['prefer_file_name']?.toString() ?? '0') ?? 0) ==
              1,
          subfolderView:
              (int.tryParse(row['subfolder_view']?.toString() ?? '0') ?? 0) ==
              1,
        );
      }

      return system;
    } catch (e) {
      if (e is! StateError) {
        _log.e('Error getting system by folder name "$folderName": $e');
      }
      throw Exception('System not found: $folderName');
    }
  }

  /// Calculates the total number of ROMs registered for a specific system.
  static Future<int> getRomCountForSystem(String systemId) async {
    final db = await instance.database;
    final results = await db.rawQuery(
      'SELECT COUNT(*) as count FROM user_roms WHERE app_system_id = ?',
      [systemId],
    );
    if (results.isEmpty) return 0;
    return int.tryParse(results.first['count']?.toString() ?? '0') ?? 0;
  }

  /// Calculates the number of ROMs a system shows in its game list — the total
  /// minus the ones the user hid.
  ///
  /// Never use this to decide whether a system still exists: a library whose
  /// games are all hidden would prune the system and take the unhide UI with
  /// it. Gate existence on [getRomCountForSystem].
  static Future<int> getVisibleRomCountForSystem(String systemId) async {
    final db = await instance.database;
    final results = await db.rawQuery(
      'SELECT COUNT(*) as count FROM user_roms '
      'WHERE app_system_id = ? AND is_hidden = 0',
      [systemId],
    );
    if (results.isEmpty) return 0;
    return int.tryParse(results.first['count']?.toString() ?? '0') ?? 0;
  }

  /// Retrieves all valid physical folder names (primary and aliases) for a system.
  static Future<List<String>> getAllFolderNamesForSystem(
    String systemId,
  ) async {
    final db = await instance.database;

    // Fetch primary folder name.
    final primary = await db.rawQuery(
      'SELECT folder_name FROM app_systems WHERE id = ?',
      [systemId],
    );

    // Fetch alternative alias names.
    final alternates = await db.rawQuery(
      'SELECT folder_name FROM app_system_folders WHERE system_id = ?',
      [systemId],
    );

    final names = <String>{};
    if (primary.isNotEmpty) {
      names.add(primary.first['folder_name'].toString());
    }
    for (final row in alternates) {
      names.add(row['folder_name'].toString());
    }

    return names.toList();
  }

  // ==========================================
  // EMULATOR DETECTION METHODS
  // ==========================================

  /// Retrieves a map of emulators detected on the host system, organized by their logical name.
  static Future<Map<String, EmulatorModel>> getUserDetectedEmulators() async {
    final db = await instance.database;

    // 1. Fetch standalone emulators explicitly configured by the user.
    final results = await db.rawQuery('''
      SELECT 
        e.name, 
        e.unique_identifier,
        e.is_standalone,
        uc.emulator_path,
        uc.created_at,
        uc.updated_at
      FROM user_emulator_config uc
      JOIN app_emulators e ON uc.emulator_unique_id = e.unique_identifier
      WHERE uc.emulator_path IS NOT NULL AND uc.emulator_path != ''
      ORDER BY uc.updated_at DESC
    ''');

    final emulators = <String, EmulatorModel>{};

    for (final row in results) {
      final name = row['name'].toString();
      final path = row['emulator_path'].toString();
      final uniqueIdentifier = row['unique_identifier']?.toString();

      if (!emulators.containsKey(name)) {
        emulators[name] = EmulatorModel(
          name: name,
          path: path,
          detected: true,
          lastDetection: row['updated_at'] != null
              ? DateTime.parse(row['updated_at'].toString())
              : DateTime.now(),
          uniqueId: uniqueIdentifier,
        );
      }
    }

    // 2. Fetch global RetroArch configuration (handles both standard and ra32 variants).
    final raResults = await db.rawQuery('''
      SELECT emulator_unique_id, emulator_path, updated_at 
      FROM user_emulator_config 
      WHERE emulator_unique_id IN ('ra', 'ra32') 
        AND emulator_path IS NOT NULL 
        AND emulator_path != ''
      ORDER BY updated_at DESC
      LIMIT 1
    ''');

    if (raResults.isNotEmpty) {
      final row = raResults.first;
      final path = row['emulator_path'].toString();
      final uniqueId = row['emulator_unique_id'].toString();

      // Consolidate under 'RetroArch' for standardized UI display.
      emulators['RetroArch'] = EmulatorModel(
        name: 'RetroArch',
        path: path,
        detected: true,
        lastDetection: row['updated_at'] != null
            ? DateTime.parse(row['updated_at'].toString())
            : DateTime.now(),
        uniqueId: uniqueId,
      );
    }

    return emulators;
  }

  /// Attempts a safe migration of an old database file to the new standardized location.
  Future<void> _attemptMigration(String newDbPath, File oldFile) async {
    if (await oldFile.exists()) {
      final file = File(newDbPath);

      // Perform migration only if the target file does not exist to prevent data loss.
      bool shouldMigrate = !await file.exists();

      if (shouldMigrate) {
        try {
          await file.parent.create(recursive: true);
          await oldFile.copy(newDbPath);

          // Clean up legacy file after successful migration.
          await oldFile.delete();
        } catch (e) {
          _log.e('Failed to migrate database to standardized path', error: e);
        }
      }
    }
  }

  /// Persists the executable path for a standalone emulator.
  static Future<void> saveDetectedEmulatorPath({
    required String emulatorName,
    required String emulatorPath,
  }) async {
    final db = await instance.database;
    final currentOs = getCurrentOs();

    await db.transaction((txn) async {
      // Specialized handling for RetroArch
      if (emulatorName == 'RetroArch') {
        const uniqueId = 'ra';

        await txn.insert('user_emulator_config', {
          'emulator_unique_id': uniqueId,
          'emulator_path': emulatorPath,
          'updated_at': DateTime.now().toIso8601String(),
        }, conflictAlgorithm: ConflictAlgorithm.replace);

        return;
      }

      // Logic for generic Standalone Emulators.
      // Retrieve the unique identifier based on name and current OS.
      final emulators = await txn.rawQuery(
        'SELECT unique_identifier FROM app_emulators WHERE name = ? AND os_id = (SELECT id FROM app_os WHERE name = ?)',
        [emulatorName, currentOs],
      );

      for (final row in emulators) {
        final uniqueId = row['unique_identifier']?.toString();
        if (uniqueId != null) {
          // Update existing configuration or insert a new one.
          final existing = await txn.query(
            'user_emulator_config',
            columns: ['emulator_unique_id'],
            where: 'emulator_unique_id = ?',
            whereArgs: [uniqueId],
          );

          if (existing.isNotEmpty) {
            await txn.update(
              'user_emulator_config',
              {
                'emulator_path': emulatorPath,
                'updated_at': DateTime.now().toIso8601String(),
              },
              where: 'emulator_unique_id = ?',
              whereArgs: [uniqueId],
            );
          } else {
            await txn.insert('user_emulator_config', {
              'emulator_unique_id': uniqueId,
              'emulator_path': emulatorPath,
              'is_user_default': 0,
              'created_at': DateTime.now().toIso8601String(),
              'updated_at': DateTime.now().toIso8601String(),
            });
          }
        }
      }
    });
  }

  /// Configures a standalone emulator path and sets it as the system default.
  static Future<void> setStandaloneEmulatorPath(
    String emulatorUniqueId,
    String path, {
    bool setAsDefault = true,
  }) async {
    final db = await instance.database;

    // 1. Resolve the associated system ID.
    final emuResult = await db.query(
      'app_emulators',
      columns: ['system_id'],
      where: 'unique_identifier = ?',
      whereArgs: [emulatorUniqueId],
      limit: 1,
    );

    String? systemId;
    if (emuResult.isNotEmpty) {
      systemId = emuResult.first['system_id']?.toString();
    }

    // 2. Persist path configuration.
    final existing = await db.query(
      'user_emulator_config',
      columns: ['emulator_unique_id'],
      where: 'emulator_unique_id = ?',
      whereArgs: [emulatorUniqueId],
    );

    if (existing.isNotEmpty) {
      await db.update(
        'user_emulator_config',
        {'emulator_path': path, 'updated_at': DateTime.now().toIso8601String()},
        where: 'emulator_unique_id = ?',
        whereArgs: [emulatorUniqueId],
      );
    } else {
      await db.insert('user_emulator_config', {
        'emulator_unique_id': emulatorUniqueId,
        'emulator_path': path,
        'is_user_default': 0,
        'created_at': DateTime.now().toIso8601String(),
        'updated_at': DateTime.now().toIso8601String(),
      });
    }

    // 3. A path selected in the UI becomes the default; discovery must not
    // replace a user's existing default just because another emulator exists.
    if (setAsDefault && systemId != null) {
      await setDefaultStandaloneEmulator(systemId, emulatorUniqueId);
    }
  }

  // ==========================================
  // SYSTEM & EMULATOR QUERY METHODS
  // ==========================================

  /// Retrieves all available systems registered in the application.
  static Future<List<SystemModel>> getAllSystems() async {
    final db = await instance.database;

    // Fetch systems with comprehensive metadata and game statistics.
    final results = await db.rawQuery('''
      SELECT s.*,
             (SELECT COUNT(*) FROM user_roms ur WHERE ur.app_system_id = s.id AND ur.is_hidden = 0) as rom_count,
             ss.recursive_scan,
             ss.custom_background_path,
             ss.custom_logo_path,
             ss.hide_logo,
             ss.hide_extension,
             ss.hide_parentheses,
             ss.hide_brackets,
             ss.prefer_file_name,
             ss.subfolder_view
      FROM app_systems s
      LEFT JOIN user_system_settings ss ON s.id = ss.app_system_id
      ORDER BY s.real_name ASC
    ''');

    return await _enrichSystemsWithFoldersAndExtensions(db, results);
  }

  /// Compatibility alias for [getAllSystems].
  static Future<List<SystemModel>> getAvailableSystems() async =>
      getAllSystems();

  /// Retrieves all emulator cores available for a specific system and operating system.
  ///
  /// The `isInstalled` on the returned models is a *package-level* check: on
  /// Android it means the emulator app is present, which for a RetroArch entry
  /// says nothing about whether the libretro core itself is there; on desktop it
  /// is unconditionally true. `loadEmulatorsForSystem` is the enumerator that
  /// verifies cores as well — prefer it unless you specifically want the cheaper
  /// package-only answer.
  static Future<List<CoreEmulatorModel>> getCoresBySystemId(
    String systemId,
  ) async {
    final db = await instance.database;
    final currentOs = getCurrentOs();

    // Ensure data corrections (like missing package names) have been applied.
    await _runDataCorrection();

    // Fetch non-standalone emulators (Libretro cores).
    final results = await db.rawQuery(
      '''
      SELECT e.*, os.name as os_name
      FROM app_emulators e
      JOIN app_os os ON e.os_id = os.id
      WHERE e.system_id = ? AND os.name = ? AND e.is_standalone = 0
      ORDER BY e.name ASC
      ''',
      [systemId, currentOs],
    );

    final processedResults = <Map<String, dynamic>>[];

    for (final row in results) {
      final newRow = Map<String, dynamic>.from(row);

      if (currentOs == 'android') {
        String? pkg = (row['android_package_name']?.toString() ?? '').trim();

        // Heuristic fallback for RetroArch variants on Android.
        if (pkg.isEmpty) {
          final uniqueId = row['unique_identifier']?.toString() ?? '';
          if (uniqueId.contains('.ra64.')) {
            pkg = 'com.retroarch.aarch64';
          } else if (uniqueId.contains('.ra32.')) {
            pkg = 'com.retroarch.ra32';
          } else if (uniqueId.contains('.ra.')) {
            pkg = 'com.retroarch';
          }
        }

        if (pkg.isNotEmpty) {
          bool isInstalled = await AndroidService.isPackageInstalled(pkg);
          newRow['is_installed'] = isInstalled ? 1 : 0;
        } else {
          newRow['is_installed'] = 0;
        }
      } else {
        newRow['is_installed'] = 1;
      }
      processedResults.add(newRow);
    }

    return processedResults
        .map((row) => CoreEmulatorModel.fromMap(row))
        .toList();
  }

  /// Corrects data inconsistencies in emulator records (e.g., missing package names).
  static Future<void> _runDataCorrection() async {
    final db = await instance.database;

    await db.transaction((txn) async {
      // Standardize 64-bit RetroArch package names.
      await txn.rawUpdate('''
        UPDATE app_emulators 
        SET android_package_name = 'com.retroarch.aarch64', is_standalone = 0
        WHERE os_id = 2 AND android_package_name IS NULL AND (unique_identifier LIKE '%.ra64.%' OR name LIKE '%RetroArch64%')
      ''');

      // Standardize 32-bit RetroArch package names.
      await txn.rawUpdate('''
        UPDATE app_emulators 
        SET android_package_name = 'com.retroarch.ra32', is_standalone = 0
        WHERE os_id = 2 AND android_package_name IS NULL AND (unique_identifier LIKE '%.ra32.%' OR name LIKE '%RetroArch32%')
      ''');

      // Standardize base RetroArch package names.
      await txn.rawUpdate('''
        UPDATE app_emulators 
        SET android_package_name = 'com.retroarch', is_standalone = 0
        WHERE os_id = 2 AND android_package_name IS NULL AND (unique_identifier LIKE '%.ra.%' OR (name LIKE '%RetroArch%' AND name NOT LIKE '%64%' AND name NOT LIKE '%32%'))
      ''');

      // Ensure all RetroArch variants are correctly flagged as cores.
      await txn.rawUpdate('''
        UPDATE app_emulators 
        SET is_standalone = 0
        WHERE os_id = 2 AND (unique_identifier LIKE '%.ra.%' OR name LIKE '%RetroArch%') AND is_standalone = 1
      ''');
    });
  }

  /// Makes [uniqueIdentifier] the one and only default emulator for [systemId],
  /// clearing every competing marker first.
  ///
  /// The system default is expressed across two tables — `app_emulators.is_default`
  /// (cores) and `user_emulator_config.is_user_default` (the user's explicit pick,
  /// core or standalone) — and [getUserDefaultEmulatorForSystem] reads the latter
  /// with a `LIMIT 1`. Anything that leaves a second `is_user_default = 1` row on
  /// the system therefore makes the resolved default non-deterministic, and in
  /// practice the *oldest* selection wins: pick a core, then a standalone, and the
  /// core still launches. Both setters funnel through here so that can't happen.
  ///
  /// The `is_user_default` clear is deliberately system-wide rather than
  /// system+OS: `user_emulator_config`'s primary key is `emulator_unique_id`
  /// alone, so a single row is shared across operating systems and anything
  /// narrower cannot make the invariant hold.
  static Future<void> _applySystemDefaultEmulator(
    TransactionAdapter txn,
    String systemId,
    String uniqueIdentifier,
    int osId, {
    required bool isStandalone,
  }) async {
    // 1. Clear the core default across the whole system+OS — standalone rows
    //    included, in case a seed ever flagged one.
    await txn.rawUpdate(
      'UPDATE app_emulators SET is_default = 0 WHERE system_id = ? AND os_id = ?',
      [systemId, osId],
    );

    // 2. Clear every explicit user default belonging to this system.
    await txn.rawUpdate(
      'UPDATE user_emulator_config SET is_user_default = 0 '
      'WHERE emulator_unique_id IN '
      '(SELECT unique_identifier FROM app_emulators WHERE system_id = ?)',
      [systemId],
    );

    // 3. Cores additionally carry the app-level default flag.
    if (!isStandalone) {
      await txn.update(
        'app_emulators',
        {'is_default': 1},
        where: 'os_id = ? AND unique_identifier = ?',
        whereArgs: [osId, uniqueIdentifier],
      );
    }

    _log.i(
      '[EmuSel] set system default: system=$systemId emulator=$uniqueIdentifier '
      'osId=$osId standalone=$isStandalone',
    );

    // 4. Record the user's pick so emulator auto-detection cannot override it
    //    on subsequent startups.
    final now = DateTime.now().toIso8601String();
    final existing = await txn.query(
      'user_emulator_config',
      columns: ['emulator_unique_id'],
      where: 'emulator_unique_id = ?',
      whereArgs: [uniqueIdentifier],
    );
    if (existing.isNotEmpty) {
      await txn.update(
        'user_emulator_config',
        {'is_user_default': 1, 'updated_at': now},
        where: 'emulator_unique_id = ?',
        whereArgs: [uniqueIdentifier],
      );
    } else {
      await txn.insert('user_emulator_config', {
        'emulator_unique_id': uniqueIdentifier,
        'emulator_path': '', // Path resolution is handled during launch.
        'is_user_default': 1,
        'created_at': now,
        'updated_at': now,
      });
    }
  }

  /// Sets the primary emulator core for a given system.
  static Future<void> setDefaultCore(
    String systemId,
    String uniqueIdentifier,
    int osId,
  ) async {
    final db = await instance.database;

    await db.transaction((txn) async {
      await _applySystemDefaultEmulator(
        txn,
        systemId,
        uniqueIdentifier,
        osId,
        isStandalone: false,
      );
    });

    // Enforce disk persistence via WAL checkpoint.
    try {
      await db.execute('PRAGMA wal_checkpoint(FULL)');
    } catch (e) {
      _log.e(
        'Failed to finalize core default update via WAL checkpoint',
        error: e,
      );
    }
  }

  /// Retrieves standalone emulators compatible with a specific system.
  static Future<List<Map<String, dynamic>>> getStandaloneEmulatorsBySystemId(
    String systemId,
  ) async {
    final db = await instance.database;
    final currentOs = getCurrentOs();

    final results = await db.rawQuery(
      '''
      SELECT 
        e.*, 
        os.name as os_name, 
        uc.emulator_path, 
        uc.is_user_default
      FROM app_emulators e
      JOIN app_os os ON e.os_id = os.id
      LEFT JOIN user_emulator_config uc ON e.unique_identifier = uc.emulator_unique_id
      WHERE e.system_id = ? AND os.name = ? AND e.is_standalone = 1
      ORDER BY e.name ASC
      ''',
      [systemId, currentOs],
    );

    return results;
  }

  /// Assigns a standalone emulator as the default for a system, unsetting core defaults.
  static Future<void> setDefaultStandaloneEmulator(
    String systemId,
    String emulatorUniqueId,
  ) async {
    final db = await instance.database;

    final osRow = await db.rawQuery('SELECT id FROM app_os WHERE name = ?', [
      getCurrentOs(),
    ]);
    final osId = osRow.isEmpty
        ? null
        : int.tryParse(osRow.first['id']?.toString() ?? '');
    if (osId == null) {
      _log.e('Cannot set standalone default: OS context unresolved');
      return;
    }

    await db.transaction((txn) async {
      await _applySystemDefaultEmulator(
        txn,
        systemId,
        emulatorUniqueId,
        osId,
        isStandalone: true,
      );
    });

    try {
      await db.execute('PRAGMA wal_checkpoint(FULL)');
    } catch (e) {
      _log.e('WAL checkpoint failed after standalone default update', error: e);
    }
  }

  /// Retrieves all emulators associated with a system across all platforms.
  static Future<List<CoreEmulatorModel>> getAllEmulatorsForSystem(
    String systemId,
  ) async {
    final db = await instance.database;
    final results = await db.rawQuery(
      '''
      SELECT e.*, os.name as os_name
      FROM app_emulators e
      JOIN app_os os ON e.os_id = os.id
      WHERE e.system_id = ?
      ORDER BY e.is_default DESC, e.name ASC
      ''',
      [systemId],
    );
    return results.map((row) => CoreEmulatorModel.fromMap(row)).toList();
  }

  /// Seeds a sane app-level default emulator for any system that lacks one, and
  /// removes app/user default contradictions. Runs on every launch.
  ///
  /// Two hard rules, both learned from bugs this routine used to cause:
  ///
  /// 1. **It never writes `user_emulator_config.is_user_default`.** That column
  ///    means "the user picked this", and [_resolveDefaultInstalledEmulator]
  ///    honors it outright — installed or not — precisely because it is a
  ///    deliberate choice. Auto-seeding it made a guess indistinguishable from a
  ///    choice, and the old PS1 branch went further and *cleared* a real user
  ///    choice on every single launch, silently reverting anyone who picked a
  ///    standalone for PS1. Seeding belongs in `app_emulators.is_default`, which
  ///    [getDefaultEmulatorForSystem] already falls back to and which resolves
  ///    standalones just as well as cores.
  /// 2. **Every statement is scoped to the current OS.** The old writes cleared
  ///    `is_default` for a system across *all* operating systems, corrupting the
  ///    other platforms' state in a synced database.
  ///
  /// Ordering is explicit throughout so the seeded pick is reproducible rather
  /// than whatever the storage engine happened to return first.
  @visibleForTesting
  static Future<void> normalizeEmulatorDefaultsForTesting(
    DatabaseExecutorAdapter db,
  ) => instance._fixEmulatorDefaults(db);

  /// Systems holding more than one *distinct* user-selected default emulator,
  /// mapped to the emulator ids competing for them.
  ///
  /// The `DISTINCT` is the whole point. `user_emulator_config`'s primary key is
  /// `emulator_unique_id` alone, so the same emulator can never appear twice —
  /// but `app_emulators` is keyed on `(os_id, unique_identifier)` and therefore
  /// holds one row per operating system the emulator is defined for. Joining
  /// them fans a single user choice out to one row per OS, and counting those
  /// rows reported a perfectly healthy database as broken: DuckStation is
  /// defined for Android, Windows, Linux and macOS, so one PS1 default logged
  /// as "system=ps1 has 4 user defaults (ps1.com.github.stenzek.duckstation
  /// ×4)". The repeated id was the tell — a real violation names *different*
  /// emulators.
  ///
  /// Counting distinct emulator ids still catches the real thing, which is two
  /// different emulators both flagged as the user's pick for one system.
  @visibleForTesting
  static Future<Map<String, List<String>>> findDuplicateUserDefaults(
    DatabaseExecutorAdapter db,
  ) async {
    final rows = await db.rawQuery('''
      SELECT e.system_id AS sid,
             GROUP_CONCAT(DISTINCT uc.emulator_unique_id) AS uids
      FROM user_emulator_config uc
      JOIN app_emulators e ON e.unique_identifier = uc.emulator_unique_id
      WHERE uc.is_user_default = 1
      GROUP BY e.system_id
      HAVING COUNT(DISTINCT uc.emulator_unique_id) > 1
    ''');

    return {
      for (final row in rows)
        row['sid'].toString(): (row['uids']?.toString() ?? '')
            .split(',')
            .where((id) => id.isNotEmpty)
            .toList(),
    };
  }

  /// Logs any system whose default-emulator state is self-contradictory.
  ///
  /// The invariant is "at most one `is_user_default` per system, and no app
  /// default contradicting it". Violations are what made a chosen emulator
  /// launch a different one, so surface them at startup rather than waiting for
  /// a user to notice the wrong emulator booting. Silent when everything is
  /// consistent, which is the normal case.
  static Future<void> logEmulatorDefaultAnomalies(
    DatabaseExecutorAdapter db,
  ) async {
    try {
      // NB: messages here deliberately avoid a word ending in "y" immediately
      // before a colon — `y` is a redacted query parameter, so "ANOMALY: system
      // ds" gets scrubbed to "ANOMALY: <redacted> ds" by the log redactor.
      final dupes = await findDuplicateUserDefaults(db);

      for (final entry in dupes.entries) {
        _log.w(
          '[EmuSel] anomaly - system=${entry.key} has ${entry.value.length} '
          'user defaults (${entry.value.join(', ')})',
        );
      }

      // Scoped to the current OS: `is_default` is per (system, os), so an
      // unscoped check reports another platform's perfectly valid default as a
      // contradiction on this one.
      final contradictions = await db.rawQuery(
        '''
        SELECT DISTINCT e.system_id AS sid
        FROM app_emulators e
        WHERE e.is_default = 1
          AND e.os_id = (SELECT id FROM app_os WHERE name = ?)
          AND EXISTS (
            SELECT 1 FROM user_emulator_config uc
            JOIN app_emulators e2
              ON e2.unique_identifier = uc.emulator_unique_id
            WHERE uc.is_user_default = 1
              AND e2.system_id = e.system_id
              AND e2.os_id = e.os_id
              AND e2.unique_identifier != e.unique_identifier
          )
        ''',
        [getCurrentOs()],
      );

      for (final row in contradictions) {
        _log.w(
          '[EmuSel] anomaly - system=${row['sid']} has an app default that '
          'contradicts the user-selected default',
        );
      }

      if (dupes.isEmpty && contradictions.isEmpty) {
        _log.i('[EmuSel] default-emulator state consistent across all systems');
      }
    } catch (e) {
      _log.w('[EmuSel] Could not scan for default-emulator anomalies: $e');
    }
  }

  Future<void> _fixEmulatorDefaults(DatabaseExecutorAdapter db) async {
    try {
      final systems = await db.query('app_systems', columns: ['id']);
      final currentOs = getCurrentOs();

      final osRow = await db.rawQuery('SELECT id FROM app_os WHERE name = ?', [
        currentOs,
      ]);
      if (osRow.isEmpty) {
        _log.w(
          'Skipping emulator default normalization: unknown OS $currentOs',
        );
        return;
      }
      final osId = int.tryParse(osRow.first['id']?.toString() ?? '');
      if (osId == null) return;

      for (final system in systems) {
        final systemId = system['id'].toString();

        final cores = await db.rawQuery(
          'SELECT * FROM app_emulators '
          'WHERE system_id = ? AND is_standalone = 0 AND os_id = ? '
          'ORDER BY name ASC',
          [systemId, osId],
        );
        final standalones = await db.rawQuery(
          '''
          SELECT e.*, uc.is_user_default
          FROM app_emulators e
          LEFT JOIN user_emulator_config uc ON e.unique_identifier = uc.emulator_unique_id
          WHERE e.system_id = ? AND e.is_standalone = 1 AND e.os_id = ?
          ORDER BY e.name ASC
          ''',
          [systemId, osId],
        );

        // "Is anything already designated for this (system, os)?" — and a
        // standalone counts. Asking only the cores made every all-standalone
        // system (switch, xbox360) look undesignated on every single database
        // open, so the seeding below ran again and flagged the alphabetically
        // first standalone *alongside* the one the systems JSON had chosen:
        // AX360e next to AX360e (Free), Benji-SC next to Eden. That is where
        // the duplicate defaults v108 repairs came from.
        final hasAppDefault =
            cores.any((c) => c['is_default'] == 1) ||
            standalones.any((s) => s['is_default'] == 1);
        final hasUserDefault = standalones.any(
          (s) => s['is_user_default'] == 1,
        );

        if (hasUserDefault) {
          // The user made a choice. It outranks any app-level default, so drop
          // the contradicting `is_default` rather than the choice.
          if (hasAppDefault) {
            await db.rawUpdate(
              'UPDATE app_emulators SET is_default = 0 '
              'WHERE system_id = ? AND os_id = ?',
              [systemId, osId],
            );
          }
          continue;
        }

        if (hasAppDefault) continue;

        // Nothing designated at all — seed the app-level default. Preference:
        // the core the systems JSON marks as canonical, then the standalone it
        // marks, then any standalone (more likely to work out of the box than
        // an unverifiable core), then any core. Falling straight to "any
        // standalone" meant an alphabetical guess overrode a seed that had a
        // perfectly good answer — the paid AX360e ahead of AX360e (Free).
        final seed =
            cores.where((c) => c['is_default_core'] == 1).firstOrNull ??
            standalones
                .where((s) => s['is_default_standalone'] == 1)
                .firstOrNull ??
            standalones.firstOrNull ??
            cores.firstOrNull;

        if (seed != null) {
          await db.rawUpdate(
            'UPDATE app_emulators SET is_default = 1 '
            'WHERE unique_identifier = ? AND os_id = ?',
            [seed['unique_identifier'], osId],
          );
        }
      }
    } catch (e) {
      _log.e('Failed to normalize emulator defaults', error: e);
    }
  }

  /// Flags well-known standalone emulators as compatible with RetroAchievements.
  Future<void> _fixAchievementCompatibility(DatabaseExecutorAdapter db) async {
    try {
      final emuNames = [
        'PPSSPP Standalone',
        'NetherSX2 Standalone',
        'DuckStation Standalone',
        'PCSX2 Standalone',
      ];

      for (final name in emuNames) {
        await db.rawUpdate(
          'UPDATE app_emulators SET is_ra_compatible = 1 WHERE name = ?',
          [name],
        );
      }
    } catch (e) {
      _log.e('Failed to flag achievement-compatible emulators', error: e);
    }
  }

  /// Retrieves the effective default emulator for a system, respecting user overrides.
  /// Returns the emulator the *user* explicitly set as default for [systemId]
  /// (`is_user_default = 1`), or null if the user hasn't chosen one. Callers use
  /// this to honor an explicit user choice before applying any auto-selection
  /// heuristics.
  static Future<CoreEmulatorModel?> getUserDefaultEmulatorForSystem(
    String systemId,
  ) async {
    final db = await instance.database;
    final currentOs = getCurrentOs();

    final userStandalone = await db.rawQuery(
      '''
      SELECT e.*, os.name as os_name, uc.emulator_path, uc.is_user_default
      FROM app_emulators e
      JOIN app_os os ON e.os_id = os.id
      JOIN user_emulator_config uc ON e.unique_identifier = uc.emulator_unique_id
      WHERE e.system_id = ? AND os.name = ? AND uc.is_user_default = 1
      ORDER BY uc.updated_at DESC
      LIMIT 1
      ''',
      [systemId, currentOs],
    );

    if (userStandalone.isNotEmpty) {
      return CoreEmulatorModel.fromMap(userStandalone.first);
    }
    return null;
  }

  static Future<CoreEmulatorModel?> getDefaultEmulatorForSystem(
    String systemId,
  ) async {
    final db = await instance.database;
    final currentOs = getCurrentOs();

    // 1. Check for user-selected standalone default.
    final userDefault = await getUserDefaultEmulatorForSystem(systemId);
    if (userDefault != null) {
      return userDefault;
    }

    // 2. Fallback to system-provided default (usually a core).
    final defaultEmu = await db.rawQuery(
      '''
      SELECT e.*, os.name as os_name
      FROM app_emulators e
      JOIN app_os os ON e.os_id = os.id
      WHERE e.system_id = ? AND os.name = ? AND e.is_default = 1
      LIMIT 1
      ''',
      [systemId, currentOs],
    );

    if (defaultEmu.isNotEmpty) {
      return CoreEmulatorModel.fromMap(defaultEmu.first);
    }

    // 3. Absolute fallback: pick any compatible emulator.
    final fallback = await db.rawQuery(
      '''
      SELECT e.*, os.name as os_name
      FROM app_emulators e
      JOIN app_os os ON e.os_id = os.id
      WHERE e.system_id = ? AND os.name = ?
      ORDER BY e.is_standalone ASC, e.name ASC
      LIMIT 1
      ''',
      [systemId, currentOs],
    );

    if (fallback.isNotEmpty) {
      return CoreEmulatorModel.fromMap(fallback.first);
    }

    return null;
  }

  /// Retrieves all games associated with a specific system.
  static Future<List<DatabaseGameModel>> getGamesBySystem(
    String systemId,
  ) async {
    final db = await instance.database;
    final results = await db.rawQuery(
      '''
      SELECT
        ur.filename, ur.rom_path, ur.is_favorite, ur.is_hidden, ur.play_time, ur.last_played,
        ur.cloud_sync_enabled, ur.title_id, ur.title_name,
        ur.app_emulator_unique_id as emulator_name,
        s.id as system_id, s.real_name as system_real_name, s.folder_name as system_folder_name,
        s.short_name as system_short_name,
        COALESCE(usm.real_name, CASE WHEN s.folder_name IN ('android') THEN ur.title_name END, ur.filename) as game_display_name,
        usm.real_name as ss_real_name,
        COALESCE(usm.description_en, CASE WHEN s.folder_name IN ('android') THEN ur.description END) as description,
        usm.description_en, usm.description_es, usm.description_fr, usm.description_de, usm.description_it, usm.description_pt,
        usm.rating,
        COALESCE(usm.release_date, CASE WHEN s.folder_name IN ('android') THEN ur.year END) as year,
        COALESCE(usm.developer, CASE WHEN s.folder_name IN ('android') THEN ur.developer END) as developer,
        COALESCE(usm.publisher, CASE WHEN s.folder_name IN ('android') THEN ur.publisher END) as publisher,
        COALESCE(usm.genre, CASE WHEN s.folder_name IN ('android') THEN ur.genre END) as genre,
        COALESCE(usm.players, CASE WHEN s.folder_name IN ('android') THEN ur.players END) as players,
        ur.box2d_aspect_ratio,
        ur.id_ra, ur.ra_hash, s.ra_id as system_ra_id,
        -- app_ra_game_list holds one row per registered hash, so a game id can
        -- appear several times with the same counts; take the first.
        (SELECT ral.num_achievements FROM app_ra_game_list ral
          WHERE ral.game_id = ur.id_ra LIMIT 1) as ra_num_achievements,
        usm.is_fully_scraped
      FROM user_roms ur
      JOIN app_systems s ON ur.app_system_id = s.id
      LEFT JOIN user_screenscraper_metadata usm ON ur.app_system_id = usm.app_system_id AND ur.filename = usm.filename
      WHERE ur.app_system_id = ?
      ORDER BY ur.is_favorite DESC, LOWER(game_display_name) ASC
''',
      [systemId],
    );

    return results.map((row) => DatabaseGameModel.fromJson(row)).toList();
  }

  /// Retrieves all games associated with a system folder name.
  static Future<List<DatabaseGameModel>> getRomsForSystem(
    String systemFolderName,
  ) async {
    final system = await getSystemByFolderName(systemFolderName);
    if (system.id == null) return [];
    return getGamesBySystem(system.id!);
  }

  /// Retrieves all games across all registered systems.
  static Future<List<DatabaseGameModel>> getAllGames() async {
    final db = await instance.database;
    final results = await db.rawQuery('''
      SELECT
        ur.filename, ur.rom_path, ur.is_favorite, ur.is_hidden, ur.play_time, ur.last_played,
        ur.cloud_sync_enabled, ur.title_id, ur.title_name,
        ur.app_emulator_unique_id as emulator_name,
        s.id as system_id, s.real_name as system_real_name, s.folder_name as system_folder_name,
        s.short_name as system_short_name,
        COALESCE(usm.real_name, CASE WHEN s.folder_name IN ('android') THEN ur.title_name END, ur.filename) as game_display_name,
        usm.real_name as ss_real_name,
        COALESCE(usm.description_en, CASE WHEN s.folder_name IN ('android') THEN ur.description END) as description,
        usm.description_en, usm.description_es, usm.description_fr, usm.description_de, usm.description_it, usm.description_pt,
        usm.rating,
        COALESCE(usm.release_date, CASE WHEN s.folder_name IN ('android') THEN ur.year END) as year,
        COALESCE(usm.developer, CASE WHEN s.folder_name IN ('android') THEN ur.developer END) as developer,
        COALESCE(usm.publisher, CASE WHEN s.folder_name IN ('android') THEN ur.publisher END) as publisher,
        COALESCE(usm.genre, CASE WHEN s.folder_name IN ('android') THEN ur.genre END) as genre,
        COALESCE(usm.players, CASE WHEN s.folder_name IN ('android') THEN ur.players END        ) as players,
        ur.box2d_aspect_ratio,
        ur.id_ra, ur.ra_hash, s.ra_id as system_ra_id,
        -- app_ra_game_list holds one row per registered hash, so a game id can
        -- appear several times with the same counts; take the first.
        (SELECT ral.num_achievements FROM app_ra_game_list ral
          WHERE ral.game_id = ur.id_ra LIMIT 1) as ra_num_achievements,
        usm.is_fully_scraped
      FROM user_roms ur
      JOIN app_systems s ON ur.app_system_id = s.id
      LEFT JOIN user_screenscraper_metadata usm ON ur.app_system_id = usm.app_system_id AND ur.filename = usm.filename
      ORDER BY ur.is_favorite DESC, LOWER(game_display_name) ASC
    ''');
    return results.map((row) => DatabaseGameModel.fromJson(row)).toList();
  }

  /// Retrieves only games marked as favorites across all registered systems.
  ///
  /// Excludes virtual/app systems that are not part of the standard ROM library.
  static Future<List<DatabaseGameModel>> getFavoriteGames() async {
    final db = await instance.database;
    final results = await db.rawQuery('''
      SELECT
        ur.filename, ur.rom_path, ur.is_favorite, ur.is_hidden, ur.play_time, ur.last_played,
        ur.cloud_sync_enabled, ur.title_id, ur.title_name,
        ur.app_emulator_unique_id as emulator_name,
        s.id as system_id, s.real_name as system_real_name, s.folder_name as system_folder_name,
        s.short_name as system_short_name,
        COALESCE(usm.real_name, CASE WHEN s.folder_name IN ('android') THEN ur.title_name END, ur.filename) as game_display_name,
        usm.real_name as ss_real_name,
        COALESCE(usm.description_en, CASE WHEN s.folder_name IN ('android') THEN ur.description END) as description,
        usm.description_en, usm.description_es, usm.description_fr, usm.description_de, usm.description_it, usm.description_pt,
        usm.rating,
        COALESCE(usm.release_date, CASE WHEN s.folder_name IN ('android') THEN ur.year END) as year,
        COALESCE(usm.developer, CASE WHEN s.folder_name IN ('android') THEN ur.developer END) as developer,
        COALESCE(usm.publisher, CASE WHEN s.folder_name IN ('android') THEN ur.publisher END) as publisher,
        COALESCE(usm.genre, CASE WHEN s.folder_name IN ('android') THEN ur.genre END) as genre,
        COALESCE(usm.players, CASE WHEN s.folder_name IN ('android') THEN ur.players END        ) as players,
        ur.box2d_aspect_ratio,
        ur.id_ra, ur.ra_hash, s.ra_id as system_ra_id,
        -- app_ra_game_list holds one row per registered hash, so a game id can
        -- appear several times with the same counts; take the first.
        (SELECT ral.num_achievements FROM app_ra_game_list ral
          WHERE ral.game_id = ur.id_ra LIMIT 1) as ra_num_achievements,
        usm.is_fully_scraped
      FROM user_roms ur
      JOIN app_systems s ON ur.app_system_id = s.id
      LEFT JOIN user_screenscraper_metadata usm ON ur.app_system_id = usm.app_system_id AND ur.filename = usm.filename
      WHERE ur.is_favorite = 1
        AND s.folder_name NOT IN ('android', 'music')
      ORDER BY ur.is_favorite DESC, LOWER(game_display_name) ASC
    ''');
    return results.map((row) => DatabaseGameModel.fromJson(row)).toList();
  }

  // ── Collections ────────────────────────────────────────────────────────────
  // User-defined groups of ROMs (`user_collections` / `user_collection_items`).
  // Only CollectionRepository may call these.

  /// Returns every collection with its membership count, cheapest ordering
  /// first.
  ///
  /// The count comes from a single grouped subquery rather than one query per
  /// collection, so listing N collections stays one round trip.
  static Future<List<Map<String, Object?>>> getCollections() async {
    final db = await instance.database;
    return db.rawQuery('''
      SELECT
        c.id, c.name, c.image_path, c.color1, c.color2, c.sort_order,
        c.created_at, c.updated_at,
        COALESCE(counts.game_count, 0) as game_count
      FROM user_collections c
      LEFT JOIN (
        SELECT collection_id, COUNT(*) as game_count
        FROM user_collection_items
        GROUP BY collection_id
      ) counts ON counts.collection_id = c.id
      ORDER BY c.sort_order ASC, LOWER(c.name) ASC
    ''');
  }

  /// Returns one collection row (with its game count), or null.
  static Future<Map<String, Object?>?> getCollectionById(String id) async {
    final db = await instance.database;
    final rows = await db.rawQuery(
      '''
      SELECT
        c.id, c.name, c.image_path, c.color1, c.color2, c.sort_order,
        c.created_at, c.updated_at,
        (SELECT COUNT(*) FROM user_collection_items ci
          WHERE ci.collection_id = c.id) as game_count
      FROM user_collections c
      WHERE c.id = ?
      LIMIT 1
      ''',
      [id],
    );
    return rows.isEmpty ? null : rows.first;
  }

  /// Inserts a collection. [id] is generated by the caller (service layer).
  ///
  /// [sortOrder] defaults to the end of the list when omitted.
  static Future<void> insertCollection({
    required String id,
    required String name,
    String? imagePath,
    String? color1,
    String? color2,
    int? sortOrder,
  }) async {
    final db = await instance.database;

    var position = sortOrder;
    if (position == null) {
      final rows = await db.rawQuery(
        'SELECT COALESCE(MAX(sort_order), -1) + 1 as next FROM user_collections',
      );
      position = (rows.first['next'] as num?)?.toInt() ?? 0;
    }

    await db.insert('user_collections', {
      'id': id,
      'name': name,
      'image_path': imagePath,
      'color1': color1,
      'color2': color2,
      'sort_order': position,
      'created_at': DateTime.now().toIso8601String(),
      'updated_at': DateTime.now().toIso8601String(),
    });
  }

  /// Updates the mutable fields of a collection.
  ///
  /// Each nullable column has a matching `clear*` flag because passing null
  /// alone cannot distinguish "leave it alone" from "unset it".
  static Future<void> updateCollection(
    String id, {
    String? name,
    String? imagePath,
    bool clearImagePath = false,
    String? color1,
    bool clearColor1 = false,
    String? color2,
    bool clearColor2 = false,
    int? sortOrder,
  }) async {
    final db = await instance.database;

    final values = <String, Object?>{
      'updated_at': DateTime.now().toIso8601String(),
    };
    if (name != null) values['name'] = name;
    if (clearImagePath) {
      values['image_path'] = null;
    } else if (imagePath != null) {
      values['image_path'] = imagePath;
    }
    if (clearColor1) {
      values['color1'] = null;
    } else if (color1 != null) {
      values['color1'] = color1;
    }
    if (clearColor2) {
      values['color2'] = null;
    } else if (color2 != null) {
      values['color2'] = color2;
    }
    if (sortOrder != null) values['sort_order'] = sortOrder;

    await db.update(
      'user_collections',
      values,
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  /// Deletes a collection and its membership rows.
  ///
  /// The membership delete is explicit rather than left to `ON DELETE CASCADE`:
  /// the cascade only fires while `PRAGMA foreign_keys` is ON, and a stray
  /// OFF (migrations toggle it) would otherwise leave orphan rows behind.
  static Future<void> deleteCollection(String id) async {
    final db = await instance.database;
    await db.delete(
      'user_collection_items',
      where: 'collection_id = ?',
      whereArgs: [id],
    );
    await db.delete('user_collections', where: 'id = ?', whereArgs: [id]);
  }

  /// Adds a ROM to a collection, appended at the end. Re-adding is a no-op.
  ///
  /// [romPath] is stored exactly as `user_roms` holds it — on Android that is a
  /// URL-encoded SAF `content://` URI, and "tidying" it here would make
  /// collections and favourites disagree about the same game.
  static Future<void> addRomToCollection(
    String collectionId,
    String romPath,
  ) async {
    final db = await instance.database;
    final rows = await db.rawQuery(
      'SELECT COALESCE(MAX(sort_order), -1) + 1 as next '
      'FROM user_collection_items WHERE collection_id = ?',
      [collectionId],
    );
    final position = (rows.first['next'] as num?)?.toInt() ?? 0;

    await db.rawInsert(
      'INSERT OR IGNORE INTO user_collection_items '
      '(collection_id, rom_path, sort_order, created_at) VALUES (?, ?, ?, ?)',
      [collectionId, romPath, position, DateTime.now().toIso8601String()],
    );
  }

  /// Removes a ROM from a collection. Removing a non-member is a no-op.
  static Future<void> removeRomFromCollection(
    String collectionId,
    String romPath,
  ) async {
    final db = await instance.database;
    await db.delete(
      'user_collection_items',
      where: 'collection_id = ? AND rom_path = ?',
      whereArgs: [collectionId, romPath],
    );
  }

  /// Returns the ids of every collection containing [romPath].
  ///
  /// One query, used to pre-tick the context menu's collection list.
  static Future<List<String>> getCollectionIdsForRom(String romPath) async {
    final db = await instance.database;
    final rows = await db.rawQuery(
      'SELECT collection_id FROM user_collection_items WHERE rom_path = ?',
      [romPath],
    );
    return rows.map((r) => r['collection_id'].toString()).toList();
  }

  /// Returns every `rom_path` that belongs to at least one collection.
  ///
  /// One query for the whole library, so the games views can badge their rows
  /// without asking per game: `user_collection_items` holds only what the user
  /// actually filed, so the set is bounded by their collections, not by the
  /// ROM count.
  static Future<Set<String>> getCollectionMemberRomPaths() async {
    final db = await instance.database;
    final rows = await db.rawQuery(
      'SELECT DISTINCT rom_path FROM user_collection_items',
    );
    return {for (final row in rows) row['rom_path'].toString()};
  }

  /// Retrieves the games in a collection, in the same shape as
  /// [getFavoriteGames].
  ///
  /// The `app_systems` join is what populates `systemFolderName` /
  /// `systemRealName` / `appSystemId`; the whole aggregate-view code path
  /// (launch, details card, secondary display) branches on those being present.
  /// Hidden ROMs are filtered at the service layer, exactly as the favourites
  /// loader does.
  static Future<List<DatabaseGameModel>> getGamesInCollection(
    String collectionId,
  ) async {
    final db = await instance.database;
    final results = await db.rawQuery(
      '''
      SELECT
        ur.filename, ur.rom_path, ur.is_favorite, ur.is_hidden, ur.play_time, ur.last_played,
        ur.cloud_sync_enabled, ur.title_id, ur.title_name,
        ur.app_emulator_unique_id as emulator_name,
        s.id as system_id, s.real_name as system_real_name, s.folder_name as system_folder_name,
        s.short_name as system_short_name,
        COALESCE(usm.real_name, CASE WHEN s.folder_name IN ('android') THEN ur.title_name END, ur.filename) as game_display_name,
        usm.real_name as ss_real_name,
        COALESCE(usm.description_en, CASE WHEN s.folder_name IN ('android') THEN ur.description END) as description,
        usm.description_en, usm.description_es, usm.description_fr, usm.description_de, usm.description_it, usm.description_pt,
        usm.rating,
        COALESCE(usm.release_date, CASE WHEN s.folder_name IN ('android') THEN ur.year END) as year,
        COALESCE(usm.developer, CASE WHEN s.folder_name IN ('android') THEN ur.developer END) as developer,
        COALESCE(usm.publisher, CASE WHEN s.folder_name IN ('android') THEN ur.publisher END) as publisher,
        COALESCE(usm.genre, CASE WHEN s.folder_name IN ('android') THEN ur.genre END) as genre,
        COALESCE(usm.players, CASE WHEN s.folder_name IN ('android') THEN ur.players END        ) as players,
        ur.box2d_aspect_ratio,
        ur.id_ra, ur.ra_hash, s.ra_id as system_ra_id,
        -- app_ra_game_list holds one row per registered hash, so a game id can
        -- appear several times with the same counts; take the first.
        (SELECT ral.num_achievements FROM app_ra_game_list ral
          WHERE ral.game_id = ur.id_ra LIMIT 1) as ra_num_achievements,
        usm.is_fully_scraped
      FROM user_roms ur
      JOIN app_systems s ON ur.app_system_id = s.id
      LEFT JOIN user_screenscraper_metadata usm ON ur.app_system_id = usm.app_system_id AND ur.filename = usm.filename
      JOIN user_collection_items ci ON ci.rom_path = ur.rom_path
      WHERE ci.collection_id = ?
        AND s.folder_name NOT IN ('android', 'music')
      ORDER BY ur.is_favorite DESC, LOWER(game_display_name) ASC
    ''',
      [collectionId],
    );
    return results.map((row) => DatabaseGameModel.fromJson(row)).toList();
  }

  /// Retrieves a single game record based on its system and filename.
  static Future<DatabaseGameModel?> getSingleGame(
    String systemId,
    String filename,
  ) async {
    final db = await instance.database;
    final results = await db.rawQuery(
      '''
      SELECT
        ur.filename, ur.rom_path, ur.is_favorite, ur.is_hidden, ur.play_time, ur.last_played,
        ur.cloud_sync_enabled, ur.title_id, ur.title_name,
        ur.app_emulator_unique_id as emulator_name,
        s.id as system_id, s.real_name as system_real_name, s.folder_name as system_folder_name,
        s.short_name as system_short_name,
        COALESCE(usm.real_name, CASE WHEN s.folder_name IN ('android') THEN ur.title_name END, ur.filename) as game_display_name,
        usm.real_name as ss_real_name,
        COALESCE(usm.description_en, CASE WHEN s.folder_name IN ('android') THEN ur.description END) as description,
        usm.description_en, usm.description_es, usm.description_fr, usm.description_de, usm.description_it, usm.description_pt,
        usm.rating,
        COALESCE(usm.release_date, CASE WHEN s.folder_name IN ('android') THEN ur.year END) as year,
        COALESCE(usm.developer, CASE WHEN s.folder_name IN ('android') THEN ur.developer END) as developer,
        COALESCE(usm.publisher, CASE WHEN s.folder_name IN ('android') THEN ur.publisher END) as publisher,
        COALESCE(usm.genre, CASE WHEN s.folder_name IN ('android') THEN ur.genre END) as genre,
        COALESCE(usm.players, CASE WHEN s.folder_name IN ('android') THEN ur.players END        ) as players,
        ur.box2d_aspect_ratio,
        ur.id_ra, ur.ra_hash, s.ra_id as system_ra_id,
        -- app_ra_game_list holds one row per registered hash, so a game id can
        -- appear several times with the same counts; take the first.
        (SELECT ral.num_achievements FROM app_ra_game_list ral
          WHERE ral.game_id = ur.id_ra LIMIT 1) as ra_num_achievements,
        usm.is_fully_scraped
      FROM user_roms ur
      JOIN app_systems s ON ur.app_system_id = s.id
      LEFT JOIN user_screenscraper_metadata usm ON ur.app_system_id = usm.app_system_id AND ur.filename = usm.filename
      WHERE ur.app_system_id = ? AND ur.filename = ?
      LIMIT 1
      ''',
      [systemId, filename],
    );

    if (results.isNotEmpty) {
      return DatabaseGameModel.fromJson(results.first);
    }
    return null;
  }

  /// Updates the last played timestamp for a specific game.
  static Future<void> recordRomPlayed(String romPath) async {
    final db = await instance.database;
    final now = DateTime.now().toIso8601String();
    await db.update(
      'user_roms',
      {'last_played': now},
      where: 'rom_path = ?',
      whereArgs: [romPath],
    );
  }

  /// Increments the accumulated play time for a specific game.
  static Future<void> updatePlayTime(String romPath, int seconds) async {
    final db = await instance.database;
    var current = await db.query(
      'user_roms',
      columns: ['play_time'],
      where: 'rom_path = ?',
      whereArgs: [romPath],
    );
    if (current.isNotEmpty) {
      final newSeconds =
          (int.tryParse(current.first['play_time']?.toString() ?? '0') ?? 0) +
          seconds;
      await db.update(
        'user_roms',
        {
          'play_time': newSeconds,
          'last_played': DateTime.now().toIso8601String(),
        },
        where: 'rom_path = ?',
        whereArgs: [romPath],
      );
    }
  }

  /// Adds playtime that was accumulated on *another* device (pulled from a
  /// cloud provider) to a game's total.
  ///
  /// Differs from [updatePlayTime] in how `last_played` is treated: local play
  /// stamps "now", whereas imported play must not — the game was last played
  /// here whenever it was last played here. [remoteLastPlayed] only moves the
  /// stamp forward when the remote session is genuinely newer, so a pull can
  /// never rewrite a more recent local session as older.
  static Future<void> applyRemotePlayTime(
    String romPath,
    int seconds, {
    DateTime? remoteLastPlayed,
  }) async {
    final db = await instance.database;
    final current = await db.query(
      'user_roms',
      columns: ['play_time', 'last_played'],
      where: 'rom_path = ?',
      whereArgs: [romPath],
    );
    if (current.isEmpty) return;

    final row = current.first;
    final values = <String, Object?>{};

    if (seconds > 0) {
      values['play_time'] =
          (int.tryParse(row['play_time']?.toString() ?? '0') ?? 0) + seconds;
    }

    if (remoteLastPlayed != null) {
      final localRaw = row['last_played']?.toString();
      final local = (localRaw == null || localRaw.isEmpty)
          ? null
          : DateTime.tryParse(localRaw);
      if (local == null || remoteLastPlayed.isAfter(local)) {
        // Stored local-naive like every other writer of this column, so the
        // UI's existing parse/format path keeps showing wall-clock time.
        values['last_played'] = remoteLastPlayed.toLocal().toIso8601String();
      }
    }

    if (values.isEmpty) return;
    await db.update(
      'user_roms',
      values,
      where: 'rom_path = ?',
      whereArgs: [romPath],
    );
  }

  /// Toggles the favorite status for a given game path.
  ///
  /// Automatically synchronizes the 'favorites' virtual system in
  /// [user_detected_systems] so the UI stays consistent without requiring
  /// a full ROM scan.
  static Future<void> toggleRomFavorite(String romPath) async {
    final db = await instance.database;
    final current = await db.query(
      'user_roms',
      columns: ['is_favorite'],
      where: 'rom_path = ?',
      whereArgs: [romPath],
    );
    if (current.isEmpty) return;

    final oldVal =
        int.tryParse(current.first['is_favorite']?.toString() ?? '0') ?? 0;
    final newVal = oldVal == 1 ? 0 : 1;

    await db.update(
      'user_roms',
      {'is_favorite': newVal},
      where: 'rom_path = ?',
      whereArgs: [romPath],
    );

    if (newVal == 1) {
      // A favorite was added — ensure the virtual system exists.
      await db.rawInsert(
        "INSERT OR IGNORE INTO user_detected_systems (app_system_id, actual_folder_name) VALUES ('favorites', 'favorites')",
      );
    } else {
      // A favorite was removed — check if any remain.
      final countResult = await db.rawQuery(
        'SELECT COUNT(*) as count FROM user_roms WHERE is_favorite = 1 AND app_system_id != \'music\'',
      );
      final remaining =
          int.tryParse(countResult.first['count'].toString()) ?? 0;
      if (remaining == 0) {
        await db.delete(
          'user_detected_systems',
          where: "app_system_id = 'favorites'",
        );
      }
    }
  }

  /// Determines if cloud synchronization is enabled for a specific game.
  static Future<bool> isRomCloudSyncEnabled(
    String systemFolderName,
    String filename,
  ) async {
    final system = await getSystemByFolderName(systemFolderName);
    final db = await instance.database;
    final results = await db.query(
      'user_roms',
      columns: ['cloud_sync_enabled'],
      where: 'app_system_id = ? AND filename = ?',
      whereArgs: [system.id, filename],
    );
    return results.isNotEmpty &&
        (int.tryParse(results.first['cloud_sync_enabled']?.toString() ?? '1') ??
                1) ==
            1;
  }

  /// Updates the cloud synchronization toggle for a specific game.
  static Future<void> updateRomCloudSyncEnabled(
    String systemFolderName,
    String filename,
    bool enabled,
  ) async {
    final db = await instance.database;
    final system = await getSystemByFolderName(systemFolderName);
    await db.update(
      'user_roms',
      {'cloud_sync_enabled': enabled ? 1 : 0},
      where: 'app_system_id = ? AND filename = ?',
      whereArgs: [system.id, filename],
    );
  }

  /// Hides or unhides a single game.
  ///
  /// Hidden ROMs stay in the database (favorites, play time, saves and cloud
  /// sync are all preserved) — they are only filtered out of the game lists.
  /// The user restores them from the system's settings dialog.
  static Future<void> setRomHidden(
    String systemFolderName,
    String filename,
    bool hidden,
  ) async {
    final db = await instance.database;
    final system = await getSystemByFolderName(systemFolderName);
    await db.update(
      'user_roms',
      {'is_hidden': hidden ? 1 : 0},
      where: 'app_system_id = ? AND filename = ?',
      whereArgs: [system.id, filename],
    );
  }

  /// Restores every hidden game of [systemId] in one shot.
  static Future<void> unhideAllRomsForSystem(String systemId) async {
    final db = await instance.database;
    await db.update(
      'user_roms',
      {'is_hidden': 0},
      where: 'app_system_id = ? AND is_hidden = 1',
      whereArgs: [systemId],
    );
  }

  /// Restores every hidden game across all systems.
  static Future<void> unhideAllRoms() async {
    final db = await instance.database;
    await db.update('user_roms', {'is_hidden': 0}, where: 'is_hidden = 1');
  }

  /// Retrieves the games hidden by the user.
  ///
  /// Pass [systemId] to scope the result to a single system; omit it (or pass
  /// the virtual `all` system) to list the hidden games of the whole library.
  static Future<List<DatabaseGameModel>> getHiddenGames({
    String? systemId,
  }) async {
    final db = await instance.database;
    final results = await db.rawQuery(
      '''
      SELECT
        ur.filename, ur.rom_path, ur.is_favorite, ur.is_hidden, ur.play_time, ur.last_played,
        ur.cloud_sync_enabled, ur.title_id, ur.title_name,
        ur.app_emulator_unique_id as emulator_name,
        s.id as system_id, s.real_name as system_real_name, s.folder_name as system_folder_name,
        s.short_name as system_short_name,
        COALESCE(usm.real_name, CASE WHEN s.folder_name IN ('android') THEN ur.title_name END, ur.filename) as game_display_name,
        usm.real_name as ss_real_name,
        usm.rating,
        ur.box2d_aspect_ratio
      FROM user_roms ur
      JOIN app_systems s ON ur.app_system_id = s.id
      LEFT JOIN user_screenscraper_metadata usm ON ur.app_system_id = usm.app_system_id AND ur.filename = usm.filename
      WHERE ur.is_hidden = 1
        ${systemId == null ? '' : 'AND ur.app_system_id = ?'}
      ORDER BY LOWER(system_real_name) ASC, LOWER(game_display_name) ASC
    ''',
      [?systemId],
    );

    return results.map((row) => DatabaseGameModel.fromJson(row)).toList();
  }

  /// Returns how many games are hidden, keyed by system id.
  ///
  /// One query for the whole library: the scan loop subtracts these from the
  /// raw ROM counts so a system card never advertises games the list won't show.
  static Future<Map<String, int>> getHiddenRomCountsBySystem() async {
    final db = await instance.database;
    final results = await db.rawQuery(
      'SELECT app_system_id, COUNT(*) as count FROM user_roms '
      'WHERE is_hidden = 1 GROUP BY app_system_id',
    );
    return {
      for (final row in results)
        row['app_system_id'].toString():
            int.tryParse(row['count']?.toString() ?? '0') ?? 0,
    };
  }

  /// Resets a game's play statistics (time and last played) to zero.
  static Future<void> resetRomPlayTime(
    String systemFolderName,
    String filename,
  ) async {
    final db = await instance.database;
    final system = await getSystemByFolderName(systemFolderName);
    await db.update(
      'user_roms',
      {'play_time': 0, 'last_played': null},
      where: 'app_system_id = ? AND filename = ?',
      whereArgs: [system.id, filename],
    );
  }

  /// Overrides the emulator used for a specific game.
  static Future<void> setRomEmulatorOverride(
    String systemFolderName,
    String filename,
    String? emulatorUniqueId,
    int? emulatorOsId,
  ) async {
    final db = await instance.database;
    final system = await getSystemByFolderName(systemFolderName);
    await db.update(
      'user_roms',
      {
        'app_emulator_unique_id': emulatorUniqueId,
        'app_emulator_os_id': emulatorOsId,
      },
      where: 'app_system_id = ? AND filename = ?',
      whereArgs: [system.id, filename],
    );
  }

  /// Retrieves all emulators available for a system on the current operating system.
  ///
  /// The returned models carry `isInstalled = false`: a database row cannot say
  /// whether an emulator is actually present. Callers that need install state
  /// must use `loadEmulatorsForSystem`, which verifies packages and core files.
  /// `hasConfiguredPath` is the only install-adjacent signal available here, and
  /// it is desktop-only.
  static Future<List<CoreEmulatorModel>> getEmulatorsForSystemCurrentOs(
    String systemId,
  ) async {
    final db = await instance.database;
    final currentOs = getCurrentOs();
    final results = await db.rawQuery(
      '''
      SELECT e.*, os.name as os_name,
        CASE
          WHEN uc.emulator_path IS NOT NULL AND uc.emulator_path != '' THEN 1
          ELSE 0
        END as has_configured_path
      FROM app_emulators e
      JOIN app_os os ON e.os_id = os.id
      LEFT JOIN user_emulator_config uc ON uc.emulator_unique_id = e.unique_identifier
      WHERE e.system_id = ? AND os.name = ?
      ORDER BY e.is_default DESC, e.is_standalone ASC, e.name ASC
      ''',
      [systemId, currentOs],
    );
    return results.map((row) => CoreEmulatorModel.fromMap(row)).toList();
  }

  /// Registers a new game entry or updates an existing one with detailed metadata.
  static Future<void> saveRom({
    required String systemFolderName,
    required String filename,
    required String romPath,
    String? raHash,
    String? ssHash,
    int? raId,
    String? titleId,
    String? titleName,
    String? emulatorName,
    String? coreName,
    bool isFavorite = false,
    DateTime? lastPlayed,
    int playTime = 0,
    String? box2dAspectRatio,
  }) async {
    final db = await instance.database;
    final system = await getSystemByFolderName(systemFolderName);

    // Per-game emulator is an OVERRIDE, not an inherited default: leave it NULL
    // (= "inherit the system default", resolved live at launch) unless the
    // caller passes an explicit choice. Freezing the default here is what made
    // per-game settings "whack-a-mole" (stale/uninstalled emulators). We only
    // store a concrete id when we can also resolve its os_id, so the composite
    // FK (app_emulator_os_id, app_emulator_unique_id) stays valid.
    String? emulatorUniqueId;
    int? emulatorOsId;
    if (emulatorName != null && emulatorName.isNotEmpty) {
      final osRow = await db.rawQuery(
        'SELECT os_id FROM app_emulators '
        'WHERE system_id = ? AND unique_identifier = ? '
        'AND os_id = (SELECT id FROM app_os WHERE name = ?) LIMIT 1',
        [system.id, emulatorName, getCurrentOs()],
      );
      if (osRow.isNotEmpty) {
        emulatorUniqueId = emulatorName;
        emulatorOsId = osRow.first['os_id'] as int?;
      }
    }

    await db.insert('user_roms', {
      'app_system_id': system.id,
      'app_emulator_unique_id': emulatorUniqueId,
      'app_emulator_os_id': emulatorOsId,
      'filename': filename,
      'rom_path': romPath,
      'ra_hash': raHash,
      'ss_hash': ssHash,
      'id_ra': raId,
      'title_id': titleId,
      'title_name': titleName,
      'is_favorite': isFavorite ? 1 : 0,
      'last_played': lastPlayed?.toIso8601String(),
      'play_time': playTime,
      'box2d_aspect_ratio': box2dAspectRatio,
      'created_at': DateTime.now().toIso8601String(),
      'updated_at': DateTime.now().toIso8601String(),
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  /// Updates the box2d aspect ratio for a specific game.
  static Future<void> updateBox2dAspectRatio(
    String systemId,
    String filename,
    String ratio,
  ) async {
    final db = await instance.database;
    await db.rawUpdate(
      'UPDATE user_roms SET box2d_aspect_ratio = ? WHERE app_system_id = ? AND filename = ?',
      [ratio, systemId, filename],
    );
  }

  /// Retrieves the preferred language configured for game scraping operations.
  static Future<String> getScraperPreferredLanguage() async {
    try {
      final db = await instance.database;
      final results = await db.query(
        'user_screenscraper_credentials',
        columns: ['preferred_language'],
        where: 'id = 1',
      );

      if (results.isNotEmpty) {
        return results.first['preferred_language']?.toString() ?? 'en';
      }
    } catch (e) {
      _log.d('Failed to retrieve preferred language from database, error: $e');
    }
    return 'en'; // Global fallback
  }

  /// Resolves the localized description of a game based on user language preferences.
  static Future<String> getLocalizedGameDescription(
    String romName,
    String systemId,
  ) async {
    final game = await getSingleGame(systemId, romName);
    if (game == null) return '';

    final lang = await getScraperPreferredLanguage();
    return game.getDescriptionForLanguage(lang);
  }

  /// Retrieves the set of valid file extensions for a specific system.
  static Future<Set<String>> getExtensionsForSystem(String systemId) async {
    final db = await instance.database;
    final results = await db.query(
      'app_system_extensions',
      where: 'system_id = ?',
      whereArgs: [systemId],
    );
    return results
        .map((row) => (row['extension'].toString()).toLowerCase())
        .toSet();
  }

  /// Generates a mapping of system folder names to their supported file extensions.
  static Future<Map<String, Set<String>>> getSystemExtensionsMap() async {
    final db = await instance.database;
    final results = await db.rawQuery('''
      SELECT s.folder_name, e.extension
      FROM app_systems s
      JOIN app_system_extensions e ON s.id = e.system_id
    ''');
    final Map<String, Set<String>> extensionMap = {};
    for (final row in results) {
      final folderName = row['folder_name'].toString();
      extensionMap
          .putIfAbsent(folderName, () => {})
          .add((row['extension'].toString()).toLowerCase());
    }
    return extensionMap;
  }

  /// Retrieves all valid file extensions supported by any system in the database.
  static Future<Set<String>> getAllValidExtensions() async {
    final db = await instance.database;
    final results = await db.query('app_system_extensions');
    return results
        .map((row) => (row['extension'].toString()).toLowerCase())
        .toSet();
  }

  // ==========================================
  // NeoSync STATE TRACKING
  // ==========================================

  /// Persists local synchronization state for a file.
  ///
  /// This is used to track modifications and versioning for cloud sync, bypassing
  /// filesystem limitations on Android (e.g., restricted 'lastModified' modification).
  static Future<void> saveSyncState(
    String provider,
    String filePath,
    int localModifiedAt,
    int cloudUpdatedAt,
    int fileSize, {
    String? fileHash,
  }) async {
    try {
      final db = await instance.database;
      // Keyed on (provider, file_path): each sync provider owns its own row for
      // a given file so RomM and NeoSync timestamps never overwrite each other.
      await db.insert('app_neo_sync_state', {
        'provider': provider,
        'file_path': filePath,
        'local_modified_at': localModifiedAt,
        'cloud_updated_at': cloudUpdatedAt,
        'file_size': fileSize,
        'file_hash': fileHash,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    } catch (e) {
      _log.e('Failed to save cloud synchronization state', error: e);
    }
  }

  /// Retrieves the recorded synchronization state for a specific file path.
  static Future<Map<String, dynamic>?> getSyncState(
    String provider,
    String filePath,
  ) async {
    try {
      final db = await instance.database;
      final results = await db.query(
        'app_neo_sync_state',
        where: 'provider = ? AND file_path = ?',
        whereArgs: [provider, filePath],
        limit: 1,
      );
      if (results.isNotEmpty) {
        return results.first;
      }
    } catch (e) {
      _log.e('Failed to retrieve cloud synchronization state', error: e);
    }
    return null;
  }

  /// Deletes all user-specific data, including configurations, ROM metadata, and scraper credentials.
  static Future<void> clearUserData() async {
    final db = await instance.database;
    await db.transaction((txn) async {
      await txn.delete('user_config');
      await txn.delete('user_roms');
      await txn.delete('user_emulator_config');
      await txn.delete('user_screenscraper_credentials');
      await txn.delete('user_screenscraper_metadata');
      await txn.delete('user_detected_systems');
      await txn.delete('user_retroarch_cores');
      await txn.delete('user_retroarch_paths');
    });
  }

  /// Retrieves a map of all emulators available in the database schema.
  static Future<Map<String, EmulatorModel>> getAvailableEmulators() async {
    final db = await instance.database;
    final results = await db.rawQuery('''
      SELECT DISTINCT e.unique_identifier, e.name, e.android_package_name, os.name as os_name
      FROM app_emulators e
      JOIN app_os os ON e.os_id = os.id
    ''');
    final emulators = <String, EmulatorModel>{};
    for (final row in results) {
      final name = row['name'].toString();
      emulators.putIfAbsent(
        name,
        () => EmulatorModel(
          name: name,
          path: '',
          detected: false,
          possiblePaths: {},
          uniqueId: row['unique_identifier']?.toString(),
        ),
      );
    }
    return emulators;
  }

  /// Retrieves the RetroAchievements hash associated with a specific ROM.
  static Future<String?> getRomRaHash(String romPath) async {
    final db = await instance.database;
    final results = await db.query(
      'user_roms',
      columns: ['ra_hash'],
      where: 'rom_path = ?',
      whereArgs: [romPath],
      limit: 1,
    );
    if (results.isNotEmpty) {
      return results.first['ra_hash']?.toString();
    }
    return null;
  }

  /// Updates the RetroAchievements hash for a registered game.
  static Future<void> updateRomRaHash(String romPath, String hash) async {
    final db = await instance.database;
    await db.update(
      'user_roms',
      {'ra_hash': hash},
      where: 'rom_path = ?',
      whereArgs: [romPath],
    );
  }

  /// Resolves the RetroAchievements game ID based on its hash and console ID.
  static Future<int?> getRetroAchievementsGameIdByHash(
    String raHash,
    String raConsoleId,
  ) async {
    final db = await instance.database;
    final results = await db.rawQuery(
      'SELECT game_id FROM app_ra_game_list WHERE hash COLLATE NOCASE = ? AND console_id = ? LIMIT 1',
      [raHash, raConsoleId],
    );
    if (results.isNotEmpty) {
      return int.tryParse(results.first['game_id']?.toString() ?? '');
    }
    return null;
  }

  /// Retrieves high-level statistics about the local library (total games and systems).
  static Future<Map<String, dynamic>> getStats() async {
    final db = await instance.database;
    final totalGames = (await db.rawQuery(
      'SELECT COUNT(*) as count FROM user_roms',
    ));
    final totalGamesCount =
        int.tryParse(totalGames.first['count']?.toString() ?? '0') ?? 0;
    final systems = (await db.rawQuery(
      'SELECT COUNT(*) as count FROM user_detected_systems',
    )).first['count'];

    return {'totalGames': totalGamesCount, 'systems': systems};
  }

  /// Identifies the current host operating system as a standardized string.
  static String getCurrentOs() {
    if (Platform.isWindows) return 'windows';
    if (Platform.isLinux) return 'linux';
    if (Platform.isMacOS) return 'macos';
    if (Platform.isAndroid) return 'android';
    if (Platform.isIOS) return 'ios';
    return 'unknown';
  }

  /// Retrieves package names for all RetroArch variants available on Android.
  static Future<List<String>> getAndroidRetroArchPackages() async {
    final db = await instance.database;

    final results = await db.rawQuery('''
      SELECT DISTINCT android_package_name 
      FROM app_emulators 
      WHERE os_id = (SELECT id FROM app_os WHERE name = 'android') 
        AND (android_package_name LIKE 'com.retroarch%')
        AND android_package_name IS NOT NULL
      ''');

    return results
        .map((row) => row['android_package_name'].toString())
        .toList();
  }

  /// The systems the user has explicitly chosen an emulator for.
  ///
  /// Used to exclude those systems from automatic default management. Both
  /// RetroArch alignment routines below previously answered "has the user
  /// chosen anything, anywhere?" with a global `COUNT(*)` and skipped
  /// wholesale if so. That made one deliberate pick on one system freeze
  /// variant alignment for *every* system: a user on a non-aarch64 build hits a
  /// launch failure, sets an emulator by hand to work around it, and thereby
  /// disables the very repair that would have fixed the rest of their library.
  /// Scoping the guard per system respects the same intent without the
  /// collateral damage.
  static const String _systemsWithUserDefaultSql =
      'SELECT e.system_id FROM user_emulator_config uc '
      'JOIN app_emulators e ON e.unique_identifier = uc.emulator_unique_id '
      'WHERE uc.is_user_default = 1 AND e.system_id IS NOT NULL';

  /// Updates [is_default] so that [preferredPackage] is the active RetroArch
  /// variant on Android. Systems the user has explicitly configured are left
  /// untouched (see [_systemsWithUserDefaultSql]). Sets only the entries marked
  /// as [is_default_core] for the preferred package, and clears conflicting
  /// standalone defaults.
  static Future<void> fixRetroArchDefaultForAndroid(
    String preferredPackage,
  ) async {
    final db = await instance.database;

    final osResult = await db.query(
      'app_os',
      where: 'name = ?',
      whereArgs: ['android'],
    );
    if (osResult.isEmpty) return;
    final osId = int.tryParse(osResult.first['id']?.toString() ?? '0') ?? 0;

    await db.transaction((txn) async {
      // Clear all RetroArch core defaults
      await txn.rawUpdate(
        'UPDATE app_emulators SET is_default = 0 '
        'WHERE os_id = ? AND android_package_name LIKE ? '
        'AND system_id NOT IN ($_systemsWithUserDefaultSql)',
        [osId, 'com.retroarch%'],
      );

      // Set default only for entries with default_core marker
      await txn.rawUpdate(
        'UPDATE app_emulators SET is_default = 1 '
        'WHERE os_id = ? AND android_package_name = ? AND is_default_core = 1 '
        'AND system_id NOT IN ($_systemsWithUserDefaultSql)',
        [osId, preferredPackage],
      );

      // Clear standalone defaults for systems that now have an RA core default
      await txn.rawUpdate(
        'UPDATE app_emulators SET is_default = 0 '
        'WHERE os_id = ? AND is_standalone = 1 AND system_id IN ('
        'SELECT DISTINCT system_id FROM app_emulators '
        'WHERE os_id = ? AND android_package_name = ? AND is_default_core = 1 AND is_default = 1'
        ') AND system_id NOT IN ($_systemsWithUserDefaultSql)',
        [osId, osId, preferredPackage],
      );
    });

    try {
      await db.execute('PRAGMA wal_checkpoint(FULL)');
    } catch (e) {
      _log.e(
        'Failed to finalize RetroArch default fix via WAL checkpoint',
        error: e,
      );
    }
  }

  /// Clears all RetroArch core defaults on Android when no RetroArch variant
  /// is installed. Systems the user has explicitly configured are left
  /// untouched (see [_systemsWithUserDefaultSql]). For systems that lose their
  /// default, falls back to a single standalone emulator: the one the systems
  /// JSON designates, or the first by name if it designates none.
  ///
  /// The fallback used to be one set-based `UPDATE ... SET is_default = 1`
  /// guarded by `NOT EXISTS`, with nothing limiting it to a single row — so it
  /// promoted *every* standalone of a qualifying system at once and left the
  /// launch target a coin flip between them, which is the same broken state
  /// migration v108 exists to repair. Resolving one winner per system in Dart
  /// also sidesteps the guard re-evaluating as rows are written.
  static Future<void> clearRetroArchDefaultsForAndroid() async {
    final db = await instance.database;

    final osResult = await db.query(
      'app_os',
      where: 'name = ?',
      whereArgs: ['android'],
    );
    if (osResult.isEmpty) return;
    final osId = int.tryParse(osResult.first['id']?.toString() ?? '0') ?? 0;

    await db.transaction((txn) async {
      // Reset all RetroArch core defaults
      await txn.rawUpdate(
        'UPDATE app_emulators SET is_default = 0 '
        'WHERE os_id = ? AND android_package_name LIKE ? '
        'AND system_id NOT IN ($_systemsWithUserDefaultSql)',
        [osId, 'com.retroarch%'],
      );

      // For systems left with no default after clearing RA, fall back to
      // exactly one standalone — the seed's pick where there is one.
      final orphaned = await txn.rawQuery(
        'SELECT DISTINCT e.system_id AS sid FROM app_emulators e '
        'WHERE e.os_id = ? AND e.android_package_name LIKE ? '
        'AND e.system_id NOT IN ($_systemsWithUserDefaultSql) '
        'AND NOT EXISTS ('
        '  SELECT 1 FROM app_emulators d '
        '  WHERE d.system_id = e.system_id AND d.os_id = ? AND d.is_default = 1'
        ')',
        [osId, 'com.retroarch%', osId],
      );

      for (final row in orphaned) {
        final systemId = row['sid']?.toString();
        if (systemId == null) continue;

        final candidates = await txn.rawQuery(
          'SELECT unique_identifier FROM app_emulators '
          'WHERE system_id = ? AND os_id = ? AND is_standalone = 1 '
          'ORDER BY is_default_standalone DESC, name ASC LIMIT 1',
          [systemId, osId],
        );
        if (candidates.isEmpty) continue;

        await txn.rawUpdate(
          'UPDATE app_emulators SET is_default = 1 '
          'WHERE system_id = ? AND os_id = ? AND unique_identifier = ?',
          [systemId, osId, candidates.first['unique_identifier']],
        );
      }
    });

    try {
      await db.execute('PRAGMA wal_checkpoint(FULL)');
    } catch (e) {
      _log.e(
        'Failed to finalize RetroArch default clear via WAL checkpoint',
        error: e,
      );
    }
  }

  /// Retrieves a list of emulators for a system (legacy alias for [getCoresBySystemId]).
  static Future<List<Map<String, dynamic>>> getEmulatorsForSystem(
    String systemId,
  ) async {
    final cores = await getCoresBySystemId(systemId);
    return cores.map((e) => e.toMap()).toList();
  }

  /// Path of the bundled RetroAchievements seed asset.
  static const String _raSeedAsset = 'assets/data/ra_insert.sql';

  /// Reads the generation stamp from the head of the RA seed asset.
  ///
  /// The generator writes `-- Auto-generated on <timestamp>` into the first few
  /// lines, so the stamp moves whenever the asset is regenerated and nobody has
  /// to remember to bump a constant. Only the first bytes are decoded — the
  /// whole file is 6 MB and decoding it is a third of what this check exists to
  /// avoid.
  ///
  /// Returns `''` if the header is missing or unreadable, which compares equal
  /// to no stored stamp and so falls back to re-seeding.
  Future<String> _readRaSeedStamp() async {
    try {
      final data = await rootBundle.load(_raSeedAsset);
      final headLength = data.lengthInBytes < 512 ? data.lengthInBytes : 512;
      final head = String.fromCharCodes(
        data.buffer.asUint8List(data.offsetInBytes, headLength),
      );
      for (final line in head.split('\n')) {
        if (line.startsWith('-- Auto-generated on ')) {
          return line.trim();
        }
      }
    } catch (e) {
      _log.w('Could not read RA seed stamp, will re-seed: $e');
    }
    return '';
  }

  /// Refreshes the local RetroAchievements game database from bundled SQL assets.
  ///
  /// Skips the whole re-seed when the bundled asset has not changed since the
  /// last successful one. That block deletes and re-inserts 18,079 rows and
  /// character-parses a 6 MB asset to do it — measured at ~275 ms on a desktop
  /// with the database on an NVMe, and it ran on every single launch. The stamp
  /// is only written after the seed succeeds, so a failed seed retries next
  /// launch rather than being cached as done.
  /// Whether this launch actually rebuilt `app_ra_game_list`.
  ///
  /// The lookup-only match pass exists to recover matches after the bundled
  /// RetroAchievements database changes. When it has not changed, walking every
  /// hashed-but-unmatched ROM again cannot produce a different answer than it
  /// did last launch — those ROMs are simply not in the list — so an unattended
  /// pass has nothing to gain from it.
  static bool raSeedChangedThisLaunch = false;

  Future<void> refreshRetroAchievementsData() async {
    try {
      final db = await database;
      final assetStamp = await _readRaSeedStamp();

      // Never let the skip-check itself cost us the seed. Anything that goes
      // wrong reading the stored stamp (a database old enough to predate the
      // column, a config row that is not there yet) must fall through to the
      // re-seed that used to be unconditional, not abort it.
      String storedStamp = '';
      try {
        storedStamp = await getRaSeedStamp();
      } catch (e) {
        _log.w('Could not read the stored RA seed stamp, will re-seed: $e');
      }

      // A matching stamp is only trustworthy if the rows are actually there.
      // A migration that recreated the table, or a partially applied seed,
      // would otherwise leave the app with an empty list it never rebuilds.
      if (assetStamp.isNotEmpty && assetStamp == storedStamp) {
        final rows = await db.rawQuery(
          'SELECT COUNT(*) AS c FROM app_ra_game_list',
        );
        final count = rows.isEmpty ? 0 : (rows.first['c'] as int? ?? 0);
        if (count > 0) {
          _log.i(
            'RetroAchievements seed unchanged ($assetStamp, $count rows) - '
            'skipping re-seed.',
          );
          return; // raSeedChangedThisLaunch stays false: nothing to re-look-up.
        }
        _log.w(
          'RetroAchievements seed stamp matched but table is empty - '
          're-seeding.',
        );
      }

      await db.transaction((txn) async {
        _log.i('Refreshing local RetroAchievements game database...');

        // Purge existing data to ensure a clean sync.
        await txn.execute('DELETE FROM app_ra_game_list');

        // Batch insert data from the SQL seed file.
        await _executeSqlFileOptimized(txn, _raSeedAsset, 'ra_insert');
      });

      if (assetStamp.isNotEmpty) {
        // Recording the stamp is an optimisation for next launch, not part of
        // the seed: a failure here costs one redundant re-seed, and must not
        // report the seed that just succeeded as failed.
        try {
          await updateRaSeedStamp(assetStamp);
        } catch (e) {
          _log.w('Could not record the RA seed stamp: $e');
        }
      }
      raSeedChangedThisLaunch = true;
      _log.i('RetroAchievements database synchronized successfully.');
    } catch (e, stackTrace) {
      _log.e(
        'Failed to refresh RetroAchievements data',
        error: e,
        stackTrace: stackTrace,
      );
      // Non-critical: allow initialization to proceed even if this sync fails.
    }
  }

  /// Finds systems whose emulators reference a RetroArch core by display name
  /// or core filename. Used by the NeoSync migration to resolve the system for
  /// legacy `saves/<core>/<game>.ext` paths.
  ///
  /// Exact `core_filename` / `name` matches rank first so a specific core
  /// folder maps to the intended system instead of an arbitrary `%...%` hit.
  static Future<List<Map<String, dynamic>>?> findSystemByCoreName(
    String coreName,
  ) async {
    try {
      final db = await instance.database;
      final results = await db.rawQuery(
        '''
        SELECT DISTINCT s.id, s.folder_name
        FROM app_emulators e
        JOIN app_systems s ON e.system_id = s.id
        WHERE e.core_filename = ? OR e.name = ? OR e.core_filename LIKE ? OR e.name LIKE ?
        ORDER BY
          (CASE WHEN e.core_filename = ? THEN 0
                WHEN e.name = ? THEN 1
                WHEN e.core_filename LIKE ? THEN 2
                ELSE 3 END),
          s.folder_name
        ''',
        [
          coreName,
          coreName,
          '%$coreName%',
          '%$coreName%',
          coreName,
          coreName,
          '$coreName%',
        ],
      );
      return results;
    } catch (e) {
      _log.e('Error finding system by core name: $e');
      return null;
    }
  }

  /// Returns the folder names of every system an emulator is registered for,
  /// keyed by its NeoSync slug (e.g. `retroarch.fceumm` -> `nes`).
  ///
  /// Used to reconcile the system of a save with the emulator that produced it:
  /// a save must never be tagged with a system the emulator doesn't support.
  /// Systems for which the emulator is the default rank first, since a core
  /// like flycast can be registered for several arcade systems (dc, naomi, aw).
  static Future<List<String>> findSystemsByEmulatorSlug(
    String neosyncSlug,
  ) async {
    try {
      final db = await instance.database;
      final results = await db.rawQuery(
        '''
        SELECT DISTINCT s.folder_name
        FROM app_emulators e
        JOIN app_systems s ON e.system_id = s.id
        WHERE e.neosync_slug = ?
        ORDER BY (CASE WHEN e.is_default = 1 THEN 0 ELSE 1 END), s.folder_name
        ''',
        [neosyncSlug],
      );
      return results
          .map((r) => r['folder_name']?.toString() ?? '')
          .where((f) => f.isNotEmpty)
          .toList();
    } catch (e) {
      _log.e('Error finding systems for emulator slug $neosyncSlug: $e');
      return const [];
    }
  }
}
